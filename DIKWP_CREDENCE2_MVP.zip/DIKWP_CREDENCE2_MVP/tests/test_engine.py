import tempfile
import unittest
from pathlib import Path

from credence2.engine import append_ledger, assess_claim, verify_ledger
from credence2.models import (
    ClaimContract, Counterexample, DIKWPMesh, EvidenceState, InteropReport,
    ReplicationAttempt, Replicator, ReproCapsule
)


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.claim = ClaimContract(
            claim_id="T-C001", version="0.1", source_repo="test/repo", claim_text="Test claim with a measurable result",
            scope="synthetic", observation_unit="scenario", baseline="baseline", metric="accuracy", success_rule=">0.1",
            falsifiers=["effect <= 0"], prohibited_inferences=["not consciousness proof"], expires_on="2030-01-01",
            dikwp=DIKWPMesh(1,1,1,1,1,["D->I"]), prior_probability=0.5,
        )
        self.capsule = ReproCapsule("T-C001","abc",True,True,True,True,True,True,True,True,5,"cpu")
        self.rep = Replicator("r1","Independent Lab",True,True,True,True)

    def attempt(self, kind="replication", result="supports"):
        return ReplicationAttempt("a1","T-C001",self.rep,kind,result,0.7,0.9,0.9,0.9,0.9)

    def test_independent_replication_reaches_e3(self):
        a = assess_claim(self.claim, self.capsule, [self.attempt()], [], None)
        self.assertGreaterEqual(a.state, EvidenceState.E3_INDEPENDENTLY_REPLICATED)

    def test_author_only_does_not_reach_e3(self):
        author = Replicator("a","Author Lab",False,True,True,True)
        att = ReplicationAttempt("a2","T-C001",author,"reproduction","supports",0.7,0.9,0.9,0.9,0.9)
        a = assess_claim(self.claim, self.capsule, [att], [], None)
        self.assertLess(a.state, EvidenceState.E3_INDEPENDENTLY_REPLICATED)

    def test_adversarial_and_interop_reaches_e5(self):
        att1 = self.attempt("replication")
        att2 = ReplicationAttempt("a2","T-C001",Replicator("r2","Other Lab",True,True,True,True),"adversarial","supports",0.5,0.9,0.9,0.9,0.9)
        interop = InteropReport("T-C001","1.0",["impl-a","impl-b"],["Lab A","Lab B"],0.95,0.9,3,[])
        a = assess_claim(self.claim, self.capsule, [att1,att2], [], interop)
        self.assertEqual(a.state, EvidenceState.E5_INTEROPERABLE_IMPLEMENTATIONS)

    def test_counterexample_is_preserved_as_caveat(self):
        c = Counterexample("ce","T-C001","x",{},"ok","fail","high",True,"all","paid")
        a = assess_claim(self.claim, self.capsule, [self.attempt()], [c], None)
        self.assertTrue(any("反例" in x for x in a.caveats))

    def test_ledger_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/"ledger.jsonl"
            append_ledger(p,"TEST",{"x":1})
            append_ledger(p,"TEST",{"x":2})
            ok,count,problems=verify_ledger(p)
            self.assertTrue(ok); self.assertEqual(count,2); self.assertEqual(problems,[])

    def test_ledger_tamper_detected(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/"ledger.jsonl"
            append_ledger(p,"TEST",{"x":1})
            text=p.read_text(); p.write_text(text.replace('"x": 1','"x": 9'))
            ok,_,_=verify_ledger(p)
            self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
