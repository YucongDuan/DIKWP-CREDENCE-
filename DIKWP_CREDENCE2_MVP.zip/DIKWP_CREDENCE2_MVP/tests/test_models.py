import unittest
from credence2.models import DIKWPMesh, InteropReport, ReproCapsule

class ModelTests(unittest.TestCase):
    def test_mesh_normalizes(self):
        m=DIKWPMesh(2,1,1,1,0,[])
        self.assertAlmostEqual(sum(m.normalized().values()),1.0)

    def test_mesh_coverage(self):
        m=DIKWPMesh(1,1,1,1,1,[f"X{i}" for i in range(25)])
        self.assertEqual(m.coverage(),1.0)

    def test_capsule_readiness(self):
        c=ReproCapsule("c","h",True,True,True,True,True,True,True,True,1,"cpu")
        self.assertEqual(c.readiness(),1.0)

    def test_interop_requires_independence(self):
        r=InteropReport("c","1",["a","b"],["same"],1,1,3,[])
        self.assertFalse(r.qualifies())

if __name__ == "__main__": unittest.main()
