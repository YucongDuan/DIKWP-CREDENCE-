"""DIKWP-CREDENCE²: federated evidence and replication engine."""

__version__ = "0.1.0"
