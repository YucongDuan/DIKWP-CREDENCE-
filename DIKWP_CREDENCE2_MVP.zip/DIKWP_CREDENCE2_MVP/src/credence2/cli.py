from __future__ import annotations

import argparse
import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List

from .dashboard import render_dashboard
from .engine import append_ledger, assess_claim, repo_readiness, verify_ledger
from .models import (
    ClaimContract,
    Counterexample,
    DIKWPMesh,
    EvidenceState,
    InteropReport,
    ReplicationAttempt,
    Replicator,
    ReproCapsule,
    RepositorySnapshot,
)
from .simulation import run_simulation, summarize


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def mesh_from(d: Dict) -> DIKWPMesh:
    return DIKWPMesh(**d)


def claim_from(d: Dict) -> ClaimContract:
    d = dict(d)
    d["dikwp"] = mesh_from(d["dikwp"])
    d["status"] = EvidenceState(d.get("status", 0))
    return ClaimContract(**d)


def capsule_from(d: Dict) -> ReproCapsule:
    return ReproCapsule(**d)


def replicator_from(d: Dict) -> Replicator:
    return Replicator(**d)


def attempt_from(d: Dict) -> ReplicationAttempt:
    d = dict(d)
    d["replicator"] = replicator_from(d["replicator"])
    return ReplicationAttempt(**d)


def main() -> None:
    parser = argparse.ArgumentParser(description="DIKWP-CREDENCE² evidence maturity demo")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=17072026)
    args = parser.parse_args()

    root = Path(args.root)
    data = root / "data"
    out = root / "outputs"
    out.mkdir(parents=True, exist_ok=True)

    repos = [RepositorySnapshot(**x) for x in load_json(data / "repo_snapshot.json")]
    claims = [claim_from(x) for x in load_json(data / "claims.json")]
    capsules = {x["claim_id"]: capsule_from(x) for x in load_json(data / "capsules.json")}
    attempts = [attempt_from(x) for x in load_json(data / "replication_attempts.json")]
    counterexamples = [Counterexample(**x) for x in load_json(data / "counterexamples.json")]
    interops = {x["claim_id"]: InteropReport(**x) for x in load_json(data / "interop_reports.json")}

    assessments = [
        assess_claim(c, capsules.get(c.claim_id), attempts, counterexamples, interops.get(c.claim_id)) for c in claims
    ]

    repo_rows = []
    for r in repos:
        item = asdict(r)
        item["readiness"] = repo_readiness(r)
        repo_rows.append(item)

    claim_map = {c.claim_id: c for c in claims}
    claim_rows = []
    for a in assessments:
        item = a.to_dict()
        item["source_repo"] = claim_map[a.claim_id].source_repo
        item["claim_text"] = claim_map[a.claim_id].claim_text
        claim_rows.append(item)

    sim_results = run_simulation(args.trials, args.seed)
    sim_summary = summarize(sim_results)

    # Fresh ledger per run
    ledger_path = out / "evidence_ledger.jsonl"
    if ledger_path.exists():
        ledger_path.unlink()
    for c in claims:
        append_ledger(ledger_path, "CLAIM_REGISTERED", {"claim_id": c.claim_id, "version": c.version, "source_repo": c.source_repo})
    for a in attempts:
        append_ledger(ledger_path, "REPLICATION_RECORDED", {"attempt_id": a.attempt_id, "claim_id": a.claim_id, "result": a.result, "organization": a.replicator.organization})
    for c in counterexamples:
        append_ledger(ledger_path, "COUNTEREXAMPLE_RECORDED", {"counterexample_id": c.counterexample_id, "claim_id": c.claim_id, "severity": c.severity})
    ledger_ok, ledger_count, ledger_problems = verify_ledger(ledger_path)

    key_findings = {
        "diagnosis": "The ecosystem is concept-rich but independent-evidence-poor; provenance and official certification must be separated from truth assessment.",
        "rules": [
            "开源不等于开放证据",
            "作者可运行不等于独立复现",
            "出处证明不等于真实性证明",
            "标准化至少需要两套独立互操作实现",
            "失败复现与最小反例必须获得持久署名和奖励",
            "证据状态属于具体主张，而不属于整个仓库",
        ],
        "first_flagship": "DIKWP-PACT should become the first external replication program because it exposes a narrow falsifiable question and preregistered scenarios.",
    }

    summary = {
        "generated_by": "DIKWP-CREDENCE² MVP 0.1.0",
        "snapshot_date": "2026-07-17",
        "repo_rows": repo_rows,
        "claim_rows": claim_rows,
        "simulation": sim_summary,
        "ledger": {"ok": ledger_ok, "count": ledger_count, "problems": ledger_problems},
        "key_findings": key_findings,
        "limitations": [
            "GitHub metadata is a public-page snapshot and not a full clone/API audit.",
            "The example posterior probabilities and simulation parameters are synthetic.",
            "Evidence state is illustrative and not an official certification of any repository.",
        ],
    }
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    with (out / "repo_readiness.csv").open("w", newline="", encoding="utf-8-sig") as f:
        cols = ["repo", "category", "stars", "root_delivery", "collaboration_signal", "release_signal", "history_signal", "inspectability_signal", "metadata_completeness", "evidence_notes"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in repo_rows:
            w.writerow({
                "repo": r["repo"], "category": r["category"], "stars": r["stars"], "root_delivery": r["root_delivery"],
                **r["readiness"], "evidence_notes": r["evidence_notes"],
            })

    with (out / "claim_evidence_matrix.csv").open("w", newline="", encoding="utf-8-sig") as f:
        cols = ["claim_id", "source_repo", "state", "state_label", "posterior_probability", "capsule_readiness", "independent_attempts", "adversarial_attempts", "interoperable", "field_attempts", "caveats"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in claim_rows:
            row = {k: r[k] for k in cols if k != "caveats"}
            row["caveats"] = "；".join(r["caveats"])
            w.writerow(row)

    with (out / "strategy_simulation.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(sim_summary[0].keys()))
        w.writeheader(); w.writerows(sim_summary)

    render_dashboard(out / "dashboard.html", summary)
    print(json.dumps({"dashboard": str(out / "dashboard.html"), "ledger_ok": ledger_ok, "claims": len(claims), "repos": len(repos)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
