from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Dict, List


def bar(value: float, label: str = "") -> str:
    pct = max(0.0, min(1.0, value)) * 100
    return f'<div class="bar"><span style="width:{pct:.1f}%"></span></div><small>{html.escape(label or f"{pct:.1f}%")}</small>'


def render_dashboard(out: Path, summary: Dict[str, object]) -> None:
    repo_rows = summary["repo_rows"]
    claim_rows = summary["claim_rows"]
    sim_rows = summary["simulation"]
    ledger = summary["ledger"]

    repo_html = "".join(
        f"<tr><td>{html.escape(r['repo'])}</td><td>{html.escape(r['category'])}</td><td>{r['stars']}</td>"
        f"<td>{html.escape(r['root_delivery'])}</td><td>{bar(r['readiness']['inspectability_signal'])}</td>"
        f"<td>{html.escape(r['evidence_notes'])}</td></tr>" for r in repo_rows
    )
    claim_html = "".join(
        f"<tr><td>{html.escape(r['claim_id'])}</td><td>{html.escape(r['source_repo'])}</td>"
        f"<td><span class='pill e{r['state']}'>{html.escape(r['state_label'])}</span></td>"
        f"<td>{bar(r['posterior_probability'], format(r['posterior_probability'], '.3f'))}</td>"
        f"<td>{r['independent_attempts']}</td><td>{r['adversarial_attempts']}</td>"
        f"<td>{'是' if r['interoperable'] else '否'}</td><td>{html.escape('；'.join(r['caveats']))}</td></tr>" for r in claim_rows
    )
    sim_html = "".join(
        f"<tr><td>{html.escape(r['strategy'])}</td><td>{r['median_public_trust']}</td>"
        f"<td>{r['median_independent_maintainers']}</td><td>{r['median_false_certification_rate']}</td>"
        f"<td>{r['median_interoperable_claims']}</td><td>{r['median_field_adoptions']}</td>"
        f"<td>{r['median_fragmentation']}</td><td>{r['survival_24m_rate']}</td></tr>" for r in sim_rows
    )

    payload = html.escape(json.dumps(summary["key_findings"], ensure_ascii=False, indent=2))
    out.write_text(f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-CREDENCE² Dashboard</title>
<style>
:root{{--ink:#15212c;--muted:#5c6a76;--line:#d9e0e6;--panel:#ffffff;--bg:#f4f7f9;--accent:#265d88;--ok:#2f6f5e;--warn:#916b1f;--bad:#8a3d44}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:var(--ink);line-height:1.55}}
header{{padding:44px 5vw 30px;background:linear-gradient(135deg,#102b43,#295f82);color:white}} header h1{{margin:0 0 8px;font-size:clamp(28px,5vw,52px)}} header p{{max-width:980px;margin:0;opacity:.9}}
main{{max-width:1500px;margin:0 auto;padding:26px}} .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}}
.card{{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:20px;box-shadow:0 7px 24px rgba(16,43,67,.06)}} .metric{{font-size:34px;font-weight:750}} .label{{color:var(--muted);font-size:13px}}
section{{margin:26px 0}} h2{{font-size:24px;margin:0 0 12px}} .tablewrap{{overflow:auto;background:white;border:1px solid var(--line);border-radius:14px}} table{{border-collapse:collapse;width:100%;min-width:980px}} th,td{{padding:11px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}} th{{position:sticky;top:0;background:#edf3f7;z-index:1}} tr:hover td{{background:#f9fbfc}}
.bar{{height:8px;background:#e7edf1;border-radius:999px;overflow:hidden;min-width:110px}} .bar span{{display:block;height:100%;background:var(--accent)}} small{{color:var(--muted)}} .pill{{display:inline-block;padding:3px 9px;border-radius:999px;background:#e8eef3;font-size:12px;white-space:nowrap}} .e3,.e4,.e5,.e6,.e7{{background:#dcefe8;color:#164f3e}} .e0,.e1{{background:#f0e7d4;color:#684b12}}
.callout{{border-left:5px solid var(--accent);background:#eef5fa;padding:18px 20px;border-radius:8px}} code,pre{{font-family:"Noto Sans Mono CJK SC",monospace}} pre{{white-space:pre-wrap;background:#10212e;color:#eef6fb;padding:18px;border-radius:12px;overflow:auto}}
footer{{padding:26px;color:var(--muted);text-align:center}} @media(max-width:720px){{main{{padding:14px}}header{{padding:30px 18px}}}}
</style></head>
<body><header><h1>DIKWP-CREDENCE²</h1><p>开放主张、独立复现、反证悬赏、互操作与公共可信扩散系统。状态针对“具体主张”而不是整个仓库；出处证明不等于真实性，作者可运行不等于独立复现。</p></header>
<main>
<div class="grid">
<div class="card"><div class="metric">{len(repo_rows)}</div><div class="label">公开仓库代表性快照</div></div>
<div class="card"><div class="metric">{len(claim_rows)}</div><div class="label">预注册示例主张</div></div>
<div class="card"><div class="metric">{sum(1 for x in claim_rows if x['state']>=3)}</div><div class="label">达到独立复现的示例主张</div></div>
<div class="card"><div class="metric">{'通过' if ledger['ok'] else '失败'}</div><div class="label">哈希证据账本验证（{ledger['count']}条）</div></div>
</div>
<section><div class="callout"><strong>当前诊断：</strong>现有生态已经覆盖理论、预测、社会、生命、治理、标准化和出处认证；关键缺口是让外部团队可以在不依赖作者解释的条件下复现、反驳、重写实现，并让失败证据与成功证据享有同等永久记录。</div></section>
<section><h2>仓库可检查性快照</h2><div class="tablewrap"><table><thead><tr><th>仓库</th><th>类别</th><th>Stars</th><th>根目录交付</th><th>可检查性信号</th><th>证据说明</th></tr></thead><tbody>{repo_html}</tbody></table></div></section>
<section><h2>主张证据状态</h2><div class="tablewrap"><table><thead><tr><th>Claim ID</th><th>来源</th><th>状态</th><th>示例后验</th><th>独立尝试</th><th>对抗尝试</th><th>互操作</th><th>限制</th></tr></thead><tbody>{claim_html}</tbody></table></div></section>
<section><h2>20,000次合成策略压力测试</h2><p>仅用于验证机制结构，不是现实成功率预测。</p><div class="tablewrap"><table><thead><tr><th>策略</th><th>公共信任</th><th>独立维护者</th><th>错误认证率</th><th>互操作主张</th><th>场景采用</th><th>碎片化</th><th>24月存续</th></tr></thead><tbody>{sim_html}</tbody></table></div></section>
<section><h2>核心发现（机器可读）</h2><pre>{payload}</pre></section>
</main><footer>DIKWP-CREDENCE² MVP · offline-first · advisory only · snapshot 2026-07-17</footer></body></html>""", encoding="utf-8")
