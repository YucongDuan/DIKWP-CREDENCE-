from __future__ import annotations

import random
from dataclasses import dataclass, asdict
from statistics import median
from typing import Dict, List


@dataclass
class StrategyResult:
    strategy: str
    public_trust: float
    independent_maintainers: int
    false_certification_rate: float
    interoperable_claims: int
    field_adoptions: int
    fragmentation: float
    survival_24m: bool


PARAMS = {
    "repo_expansion": {
        "trust": 0.20, "maintainers": 1.2, "false": 0.31, "interop": 0.6, "field": 0.8, "fragment": 0.76, "survival": 0.43,
    },
    "official_badge": {
        "trust": 0.34, "maintainers": 2.2, "false": 0.24, "interop": 1.4, "field": 1.5, "fragment": 0.54, "survival": 0.56,
    },
    "author_reproducible": {
        "trust": 0.49, "maintainers": 4.1, "false": 0.16, "interop": 2.6, "field": 2.3, "fragment": 0.39, "survival": 0.69,
    },
    "federated_credence": {
        "trust": 0.72, "maintainers": 9.0, "false": 0.07, "interop": 6.5, "field": 5.2, "fragment": 0.22, "survival": 0.84,
    },
}


def beta_noise(rng: random.Random, mean: float, concentration: float = 20.0) -> float:
    a = max(0.1, mean * concentration)
    b = max(0.1, (1 - mean) * concentration)
    return rng.betavariate(a, b)


def poisson_like(rng: random.Random, lam: float) -> int:
    # Knuth, adequate for small synthetic values
    L = pow(2.718281828, -lam)
    k = 0
    p = 1.0
    while p > L:
        k += 1
        p *= rng.random()
    return max(0, k - 1)


def run_simulation(trials: int = 20000, seed: int = 17072026) -> List[StrategyResult]:
    rng = random.Random(seed)
    results: List[StrategyResult] = []
    for strategy, p in PARAMS.items():
        for _ in range(trials):
            shock = rng.gauss(0, 0.035)
            trust = min(1.0, max(0.0, beta_noise(rng, min(0.95, max(0.05, p["trust"] + shock)))))
            maintainers = poisson_like(rng, p["maintainers"] * (0.75 + trust / 2))
            false_rate = min(1.0, max(0.0, beta_noise(rng, p["false"], 30)))
            interop = poisson_like(rng, p["interop"] * (0.7 + trust / 2))
            field = poisson_like(rng, p["field"] * (0.7 + trust / 2))
            fragment = min(1.0, max(0.0, beta_noise(rng, p["fragment"], 25)))
            survival_prob = min(0.98, max(0.02, p["survival"] + 0.18 * trust - 0.16 * fragment - 0.2 * false_rate))
            results.append(
                StrategyResult(
                    strategy=strategy,
                    public_trust=trust,
                    independent_maintainers=maintainers,
                    false_certification_rate=false_rate,
                    interoperable_claims=interop,
                    field_adoptions=field,
                    fragmentation=fragment,
                    survival_24m=rng.random() < survival_prob,
                )
            )
    return results


def summarize(results: List[StrategyResult]) -> List[Dict[str, object]]:
    grouped: Dict[str, List[StrategyResult]] = {}
    for r in results:
        grouped.setdefault(r.strategy, []).append(r)
    rows: List[Dict[str, object]] = []
    for strategy, items in grouped.items():
        rows.append(
            {
                "strategy": strategy,
                "trials": len(items),
                "median_public_trust": round(median(x.public_trust for x in items), 3),
                "median_independent_maintainers": int(median(x.independent_maintainers for x in items)),
                "median_false_certification_rate": round(median(x.false_certification_rate for x in items), 3),
                "median_interoperable_claims": int(median(x.interoperable_claims for x in items)),
                "median_field_adoptions": int(median(x.field_adoptions for x in items)),
                "median_fragmentation": round(median(x.fragmentation for x in items), 3),
                "survival_24m_rate": round(sum(x.survival_24m for x in items) / len(items), 3),
            }
        )
    return rows
