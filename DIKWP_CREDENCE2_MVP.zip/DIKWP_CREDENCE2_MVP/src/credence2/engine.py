from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .models import (
    ClaimAssessment,
    ClaimContract,
    Counterexample,
    EvidenceState,
    InteropReport,
    ReplicationAttempt,
    ReproCapsule,
    RepositorySnapshot,
)


POSITIVE_TYPES = {"reproduction", "replication", "robustness", "adversarial", "field", "interoperability"}


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def logit(p: float) -> float:
    p = clamp(p, 1e-6, 1 - 1e-6)
    return math.log(p / (1 - p))


def logistic(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def likelihood_ratio(attempt: ReplicationAttempt) -> float:
    """Conservative illustrative LR. Real programs should preregister domain-specific LRs."""
    magnitude = clamp(abs(attempt.effect_size), 0.0, 1.0)
    if attempt.result == "supports":
        return 1.0 + 4.0 * magnitude
    if attempt.result == "contradicts":
        return 1.0 / (1.0 + 5.0 * magnitude)
    if attempt.result == "mixed":
        return 1.0
    return 1.0


def update_probability(prior: float, attempts: Sequence[ReplicationAttempt]) -> Tuple[float, float, float]:
    odds_log = logit(prior)
    support = 0.0
    contradiction = 0.0
    # simple correlation discount by organization and attempt type
    seen: Dict[Tuple[str, str], int] = {}
    for att in attempts:
        key = (att.replicator.organization, att.attempt_type)
        n = seen.get(key, 0)
        seen[key] = n + 1
        correlation_discount = 1 / (1 + 0.6 * n)
        w = att.evidence_weight() * correlation_discount
        lr = likelihood_ratio(att)
        odds_log += w * math.log(lr)
        if att.result == "supports":
            support += w
        elif att.result == "contradicts":
            contradiction += w
    return logistic(odds_log), support, contradiction


def assess_claim(
    claim: ClaimContract,
    capsule: Optional[ReproCapsule],
    attempts: Sequence[ReplicationAttempt],
    counterexamples: Sequence[Counterexample],
    interop: Optional[InteropReport] = None,
) -> ClaimAssessment:
    relevant = [a for a in attempts if a.claim_id == claim.claim_id and a.result != "invalid"]
    posterior, support, contradiction = update_probability(claim.prior_probability, relevant)
    readiness = capsule.readiness() if capsule else 0.0
    independent = [a for a in relevant if a.replicator.independent_from_author and a.attempt_type in {"replication", "robustness", "adversarial", "field", "interoperability"}]
    adversarial = [a for a in relevant if a.attempt_type == "adversarial"]
    fields = [a for a in relevant if a.attempt_type == "field"]
    reproducible_counterexamples = [c for c in counterexamples if c.claim_id == claim.claim_id and c.reproducible]
    interop_ok = bool(interop and interop.qualifies())

    state = EvidenceState.E0_NARRATIVE
    if capsule and capsule.source_unpacked:
        state = EvidenceState.E1_INSPECTABLE_ARTIFACT
    if capsule and readiness >= 0.625 and any(a.attempt_type == "reproduction" and a.result in {"supports", "mixed"} for a in relevant):
        state = EvidenceState.E2_AUTHOR_REPRODUCIBLE
    if len(independent) >= 1 and any(a.result == "supports" for a in independent):
        state = EvidenceState.E3_INDEPENDENTLY_REPLICATED
    if state >= EvidenceState.E3_INDEPENDENTLY_REPLICATED and len(adversarial) >= 1 and contradiction < 0.8:
        state = EvidenceState.E4_ADVERSARIALLY_ROBUST
    if state >= EvidenceState.E4_ADVERSARIALLY_ROBUST and interop_ok:
        state = EvidenceState.E5_INTEROPERABLE_IMPLEMENTATIONS
    if state >= EvidenceState.E5_INTEROPERABLE_IMPLEMENTATIONS and len(fields) >= 1:
        state = EvidenceState.E6_FIELD_VALIDATED
    # E7 requires external governance and multiple field validations; not inferred by default.
    if state >= EvidenceState.E6_FIELD_VALIDATED and len(fields) >= 3 and len({a.replicator.organization for a in fields}) >= 3:
        state = EvidenceState.E7_PUBLIC_INFRASTRUCTURE

    caveats: List[str] = []
    if claim.validate():
        caveats.extend(claim.validate())
    if readiness < 0.75:
        caveats.append("复现胶囊尚不完整")
    if len(independent) == 0:
        caveats.append("尚无独立复现")
    if not adversarial:
        caveats.append("尚无预注册反证/对抗测试")
    if reproducible_counterexamples:
        caveats.append(f"存在{len(reproducible_counterexamples)}个可复现反例")
    if not interop_ok:
        caveats.append("尚未证明至少两套独立实现互操作")
    try:
        if date.fromisoformat(claim.expires_on) < date.today():
            caveats.append("主张已过期，须重新验证")
    except ValueError:
        pass

    return ClaimAssessment(
        claim_id=claim.claim_id,
        state=state,
        posterior_probability=posterior,
        support_weight=support,
        contradiction_weight=contradiction,
        capsule_readiness=readiness,
        independent_attempts=len(independent),
        adversarial_attempts=len(adversarial),
        interoperable=interop_ok,
        field_attempts=len(fields),
        caveats=caveats,
    )


def repo_readiness(snapshot: RepositorySnapshot) -> Dict[str, float]:
    """Metadata-only readiness indicators; unknown fields are not silently treated as zero."""
    known_collab = [v for v in [snapshot.forks, snapshot.issues, snapshot.pull_requests] if v is not None]
    collaboration = 0.0 if not known_collab else clamp(sum(min(v, 5) for v in known_collab) / (len(known_collab) * 5))
    release = 0.0 if snapshot.releases is None else clamp(snapshot.releases / 2)
    history = 0.0 if snapshot.commits is None else clamp(snapshot.commits / 20)
    packaging = {
        "zip-only": 0.2,
        "readme-license-zip": 0.25,
        "unpacked-source": 0.75,
        "release-with-source": 0.85,
        "unknown": 0.35,
    }.get(snapshot.root_delivery, 0.35)
    return {
        "collaboration_signal": round(collaboration, 3),
        "release_signal": round(release, 3),
        "history_signal": round(history, 3),
        "inspectability_signal": round(packaging, 3),
        "metadata_completeness": round(sum(v is not None for v in [snapshot.forks, snapshot.issues, snapshot.pull_requests, snapshot.commits, snapshot.releases]) / 5, 3),
    }


def canonical_hash(payload: object) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def append_ledger(path: Path, event_type: str, payload: Dict[str, object]) -> Dict[str, object]:
    path.parent.mkdir(parents=True, exist_ok=True)
    prev_hash = "GENESIS"
    if path.exists():
        lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if lines:
            prev_hash = json.loads(lines[-1])["event_hash"]
    event = {
        "event_type": event_type,
        "payload": payload,
        "previous_hash": prev_hash,
    }
    event["event_hash"] = canonical_hash(event)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
    return event


def verify_ledger(path: Path) -> Tuple[bool, int, List[str]]:
    if not path.exists():
        return True, 0, []
    prev = "GENESIS"
    problems: List[str] = []
    count = 0
    for idx, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        count += 1
        event = json.loads(line)
        stored = event.pop("event_hash")
        if event.get("previous_hash") != prev:
            problems.append(f"第{idx}条 previous_hash 不匹配")
        calc = canonical_hash(event)
        if calc != stored:
            problems.append(f"第{idx}条 event_hash 不匹配")
        prev = stored
    return not problems, count, problems
