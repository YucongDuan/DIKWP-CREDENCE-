from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import date
from enum import IntEnum
from typing import Any, Dict, List, Optional


class EvidenceState(IntEnum):
    """Per-claim evidence maturity. This is not a repo-wide quality grade."""

    E0_NARRATIVE = 0
    E1_INSPECTABLE_ARTIFACT = 1
    E2_AUTHOR_REPRODUCIBLE = 2
    E3_INDEPENDENTLY_REPLICATED = 3
    E4_ADVERSARIALLY_ROBUST = 4
    E5_INTEROPERABLE_IMPLEMENTATIONS = 5
    E6_FIELD_VALIDATED = 6
    E7_PUBLIC_INFRASTRUCTURE = 7

    @property
    def label_zh(self) -> str:
        return {
            0: "E0 叙事主张",
            1: "E1 可检查工件",
            2: "E2 作者环境可复现",
            3: "E3 独立复现",
            4: "E4 反证与稳健性通过",
            5: "E5 独立互操作实现",
            6: "E6 真实场景验证",
            7: "E7 公共基础设施",
        }[int(self)]


@dataclass
class DIKWPMesh:
    """Mixed, co-equal DIKWP semantic resources for a claim."""

    D: float
    I: float
    K: float
    W: float
    P: float
    transformations: List[str] = field(default_factory=list)

    def normalized(self) -> Dict[str, float]:
        raw = {"D": self.D, "I": self.I, "K": self.K, "W": self.W, "P": self.P}
        total = sum(max(0.0, v) for v in raw.values()) or 1.0
        return {k: max(0.0, v) / total for k, v in raw.items()}

    def coverage(self) -> float:
        unique = {x.strip().upper() for x in self.transformations}
        return min(1.0, len(unique) / 25.0)


@dataclass
class ClaimContract:
    claim_id: str
    version: str
    source_repo: str
    claim_text: str
    scope: str
    observation_unit: str
    baseline: str
    metric: str
    success_rule: str
    falsifiers: List[str]
    prohibited_inferences: List[str]
    expires_on: str
    dikwp: DIKWPMesh
    prior_probability: float = 0.5
    status: EvidenceState = EvidenceState.E0_NARRATIVE
    tags: List[str] = field(default_factory=list)

    def validate(self) -> List[str]:
        issues: List[str] = []
        if not self.claim_id or not self.version:
            issues.append("claim_id/version 缺失")
        if len(self.falsifiers) == 0:
            issues.append("没有预注册反证条件")
        if len(self.prohibited_inferences) == 0:
            issues.append("没有禁止外推声明")
        if not 0 < self.prior_probability < 1:
            issues.append("先验概率必须位于(0,1)")
        try:
            date.fromisoformat(self.expires_on)
        except ValueError:
            issues.append("expires_on 不是 ISO 日期")
        return issues


@dataclass
class ReproCapsule:
    claim_id: str
    source_commit: str
    source_unpacked: bool
    environment_locked: bool
    one_command_run: bool
    sbom_present: bool
    data_manifest_present: bool
    deterministic_seed: bool
    reference_outputs: bool
    artifact_attestation: bool
    expected_runtime_minutes: int
    compute_profile: str

    def readiness(self) -> float:
        checks = [
            self.source_unpacked,
            self.environment_locked,
            self.one_command_run,
            self.sbom_present,
            self.data_manifest_present,
            self.deterministic_seed,
            self.reference_outputs,
            self.artifact_attestation,
        ]
        return sum(bool(x) for x in checks) / len(checks)


@dataclass
class Replicator:
    replicator_id: str
    organization: str
    independent_from_author: bool
    funding_disclosed: bool
    method_preregistered: bool
    raw_outputs_public: bool
    conflict_notes: str = ""
    calibration_score: float = 0.5

    def independence_score(self) -> float:
        components = [
            1.0 if self.independent_from_author else 0.15,
            1.0 if self.funding_disclosed else 0.45,
            1.0 if self.method_preregistered else 0.55,
            1.0 if self.raw_outputs_public else 0.45,
        ]
        return sum(components) / len(components)


@dataclass
class ReplicationAttempt:
    attempt_id: str
    claim_id: str
    replicator: Replicator
    attempt_type: str  # reproduction, robustness, replication, adversarial, field, interoperability
    result: str  # supports, contradicts, mixed, invalid
    effect_size: float
    design_quality: float
    context_match: float
    provenance_quality: float
    freshness: float
    protocol_deviations: List[str] = field(default_factory=list)
    notes: str = ""

    def evidence_weight(self) -> float:
        return max(
            0.0,
            min(
                1.0,
                self.replicator.independence_score()
                * self.design_quality
                * self.context_match
                * self.provenance_quality
                * self.freshness,
            ),
        )


@dataclass
class Counterexample:
    counterexample_id: str
    claim_id: str
    submitted_by: str
    minimal_input: Dict[str, Any]
    expected: str
    observed: str
    severity: str
    reproducible: bool
    scope: str
    bounty_status: str


@dataclass
class InteropReport:
    claim_id: str
    specification_version: str
    implementations: List[str]
    independent_organizations: List[str]
    feature_matrix_pass_rate: float
    negative_tests_pass_rate: float
    exchange_roundtrips: int
    unresolved_differences: List[str]

    def qualifies(self) -> bool:
        return (
            len(set(self.implementations)) >= 2
            and len(set(self.independent_organizations)) >= 2
            and self.feature_matrix_pass_rate >= 0.9
            and self.negative_tests_pass_rate >= 0.85
            and self.exchange_roundtrips >= 2
        )


@dataclass
class RepositorySnapshot:
    repo: str
    description: str
    stars: int
    forks: Optional[int]
    issues: Optional[int]
    pull_requests: Optional[int]
    commits: Optional[int]
    releases: Optional[int]
    root_delivery: str
    evidence_notes: str
    category: str
    observed_on: str
    metadata_confidence: str = "public-page-snapshot"


@dataclass
class ClaimAssessment:
    claim_id: str
    state: EvidenceState
    posterior_probability: float
    support_weight: float
    contradiction_weight: float
    capsule_readiness: float
    independent_attempts: int
    adversarial_attempts: int
    interoperable: bool
    field_attempts: int
    caveats: List[str]

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["state"] = int(self.state)
        d["state_label"] = self.state.label_zh
        return d
