# Reproduce this claim

1. Claim ID and exact version
2. Source commit hash
3. Supported operating systems and architectures
4. Environment lock / container digest
5. Dataset manifest and license
6. One-command execution
7. Expected runtime and compute profile
8. Deterministic seeds and nondeterminism disclosures
9. Reference outputs and tolerances
10. SBOM and artifact attestation
11. Known failures
12. How to submit a contradictory result
