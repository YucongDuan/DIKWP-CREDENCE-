# Minimal Counterexample

- Counterexample ID:
- Claim ID / version:
- Smallest input that fails:
- Expected behavior:
- Observed behavior:
- Reproduction command:
- Scope of failure:
- Severity:
- Suggested fix (optional):
- Bounty payment address / attribution:
