# Independent Replication Report

- Claim ID / version:
- Replicating organization:
- Funding and conflict disclosure:
- Preregistration URI:
- Attempt type: reproduction / robustness / replication / adversarial / field / interoperability
- Protocol deviations:
- Raw output location:
- Result: supports / contradicts / mixed / invalid
- Effect size and uncertainty:
- Minimal counterexample (if any):
- What this result does **not** establish:
- Signed attestation:
