# CREDENCE Governance Minimum

1. Origin attribution and evidence assessment are separate functions.
2. The claim author cannot be the sole evidence-state issuer.
3. Negative results receive the same ledger permanence as positive results.
4. Forks and independent implementations may attain higher evidence maturity than the canonical repository.
5. Evidence states expire when the claim, dependency, model, dataset or operating context changes materially.
6. Standards eligibility begins only at E5, with at least two independent interoperable implementations.
7. Deployment authority is governed separately; an E-state never grants public authority.
