# Security Policy

Report vulnerabilities privately before public disclosure when exploitation could cause harm. A security report must not be used to suppress a scientific counterexample. Security triage and claim-validity triage are separate processes.
