from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from collections import Counter
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

ROOT=Path('/mnt/data/DIKWP_CREDENCE2_MVP')
FIG=ROOT/'docs'/'figures'; FIG.mkdir(parents=True,exist_ok=True)
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc')
plt.rcParams['font.family']='Noto Sans CJK JP'
plt.rcParams['axes.unicode_minus']=False

repos=json.loads((ROOT/'data/repo_snapshot.json').read_text())
summary=json.loads((ROOT/'outputs/summary.json').read_text())

# 1 category landscape
macro = {}
for r in repos:
    c=r['category']
    if c in {'DIKWP语义内核','智能体保障与基准'}: g='语义与智能体保障内核'
    elif c in {'证据与来源','运行轨迹与审计','标准化与符合性','出处与生态认证','原创归属与发布','生态运营'}: g='证据、标准与生态信任'
    elif c in {'生态资源路由','预测与结算'}: g='预测与组合管理'
    elif c in {'人工意识与智能体基准','生命判定'}: g='生命与意识研究'
    elif c in {'社会韧性与权利','公共治理'}: g='公共治理与社会韧性'
    else: g='试点与采用'
    macro[g]=macro.get(g,0)+1
labels=list(macro.keys()); values=[macro[x] for x in labels]
fig,ax=plt.subplots(figsize=(11,6.2))
y=np.arange(len(labels))
ax.barh(y,values,color='#2b6388')
ax.set_yticks(y,labels)
ax.invert_yaxis(); ax.set_xlabel('代表性仓库数量（15个公开快照样本，宏观归类）')
ax.set_title('图1  段玉聪GitHub代表性仓库：能力版图已经很宽，外部证据层仍是横向缺口',pad=14,weight='bold')
for i,v in enumerate(values): ax.text(v+0.04,i,str(v),va='center')
ax.spines[['top','right']].set_visible(False); ax.grid(axis='x',alpha=.2)
fig.tight_layout(); fig.savefig(FIG/'fig1_repo_landscape.png',dpi=220); plt.close(fig)

# 2 trust gap chain diagram
fig,ax=plt.subplots(figsize=(13,5.6)); ax.set_xlim(0,13); ax.set_ylim(0,5.6); ax.axis('off')
steps=[('原创思想','作者提出'),('开源工件','代码/文档'),('作者复现','同数据同实现'),('独立复现','独立团队'),('反证稳健','最小反例'),('互操作','两套实现'),('场景验证','真实影响'),('公共标准','可替代运营')]
xs=np.linspace(.8,12.2,len(steps))
for idx,(t,s) in enumerate(steps):
    x=xs[idx]
    box=FancyBboxPatch((x-.62,2.05),1.24,1.28,boxstyle='round,pad=.05,rounding_size=.12',facecolor='#f2f6f8',edgecolor='#315f7d',linewidth=1.4)
    ax.add_patch(box); ax.text(x,2.78,t,ha='center',va='center',fontsize=11,weight='bold'); ax.text(x,2.38,s,ha='center',va='center',fontsize=8.8,color='#56636d')
    if idx<len(steps)-1: ax.add_patch(FancyArrowPatch((x+.65,2.69),(xs[idx+1]-.65,2.69),arrowstyle='-|>',mutation_scale=13,color='#55788f'))
ax.text(6.5,4.55,'现有生态覆盖了左侧的大部分能力；CREDENCE²补齐从“工件存在”到“外部可信”的断裂链',ha='center',fontsize=15,weight='bold')
ax.annotate('关键断点',xy=(xs[2]+.7,2.0),xytext=(xs[3],.9),arrowprops=dict(arrowstyle='->',color='#9a463f',lw=2),ha='center',color='#9a463f',weight='bold')
ax.text(6.5,.25,'出处、Stars、官方徽章都不能替代独立复现；每个证据状态必须绑定具体主张而不是整个仓库。',ha='center',fontsize=10.5,color='#3f4d56')
fig.tight_layout(); fig.savefig(FIG/'fig2_trust_gap_chain.png',dpi=220,bbox_inches='tight'); plt.close(fig)

# 3 evidence states ladder
fig,ax=plt.subplots(figsize=(10,7)); ax.set_xlim(0,10); ax.set_ylim(0,8.4); ax.axis('off')
states=[('E0','叙事主张','有想法，但尚未形成可检验合同'),('E1','可检查工件','源码、数据、文档可被审阅'),('E2','作者环境可复现','同数据同代码可得到参考输出'),('E3','独立复现','独立团队用独立环境验证'),('E4','反证与稳健','对抗测试、替代分析、最小反例'),('E5','互操作实现','至少两套独立实现可互操作'),('E6','真实场景验证','有受影响者、成本和副作用结算'),('E7','公共基础设施','创始人非必要、持续维护和替代运营')]
for i,(e,t,d) in enumerate(states):
    y=.6+i*.92; x=.6+i*.45; w=8.6-i*.45
    ax.add_patch(FancyBboxPatch((x,y),w,.72,boxstyle='round,pad=.03,rounding_size=.08',facecolor=plt.cm.Blues(.27+i*.075),edgecolor='#315f7d'))
    ax.text(x+.18,y+.47,e,weight='bold',fontsize=12,va='center'); ax.text(x+1.05,y+.47,t,weight='bold',fontsize=11,va='center'); ax.text(x+3.1,y+.47,d,fontsize=9.4,va='center')
ax.set_title('图3  CREDENCE²证据状态：状态属于“主张”，不属于“项目品牌”',fontsize=15,weight='bold',pad=12)
fig.tight_layout(); fig.savefig(FIG/'fig3_evidence_states.png',dpi=220); plt.close(fig)

# 4 claim evidence mesh
fig,ax=plt.subplots(figsize=(11,7)); ax.set_xlim(-5.5,5.5); ax.set_ylim(-4.4,4.4); ax.axis('off')
center=(0,0)
ax.add_patch(Circle(center,1.15,facecolor='#1f5579',edgecolor='white',lw=2)); ax.text(0,.2,'Claim\nContract',ha='center',va='center',color='white',fontsize=15,weight='bold'); ax.text(0,-.62,'版本化·可反证',ha='center',color='white',fontsize=9)
nodes=[('D\n数据与来源',(-3.7,2.3),'#dcebf2'),('I\n关系与异常',(0,3.35),'#e6edf5'),('K\n模型与反事实',(3.7,2.3),'#dfe8de'),('W\n权利与长期后果',(3.7,-2.3),'#f0e6d7'),('P\n用途与禁止外推',(0,-3.35),'#eadde8'),('反例/失败',(-3.7,-2.3),'#f1dddd')]
for name,(x,y),c in nodes:
    ax.add_patch(FancyBboxPatch((x-.9,y-.52),1.8,1.04,boxstyle='round,pad=.04,rounding_size=.12',facecolor=c,edgecolor='#526e80'))
    ax.text(x,y,name,ha='center',va='center',fontsize=10.5,weight='bold')
    ax.add_patch(FancyArrowPatch((0,0),(x*.76,y*.76),arrowstyle='<|-|>',mutation_scale=12,color='#6a7d8a',connectionstyle='arc3,rad=.08'))
# external ring
ext=[('独立复现节点',(-4.3,0)),('互操作实现',(4.3,0)),('场景参与者',(2.15,-3.75)),('对抗红队',(-2.15,-3.75))]
for name,(x,y) in ext:
    ax.text(x,y,name,ha='center',va='center',fontsize=9,color='#344d5c',bbox=dict(boxstyle='round,pad=.25',facecolor='white',edgecolor='#8298a6'))
ax.set_title('图4  主张不是一段README文字，而是可被多主体改写的DIKWP证据网',fontsize=15,weight='bold',pad=12)
fig.tight_layout(); fig.savefig(FIG/'fig4_claim_evidence_mesh.png',dpi=220); plt.close(fig)

# 5 simulation chart
sim=summary['simulation']; names=['仓库扩张','官方徽章','作者可复现','联邦复现网络']; keys=['repo_expansion','official_badge','author_reproducible','federated_credence']
lookup={r['strategy']:r for r in sim}
trust=[lookup[k]['median_public_trust'] for k in keys]
false=[lookup[k]['median_false_certification_rate'] for k in keys]
survive=[lookup[k]['survival_24m_rate'] for k in keys]
x=np.arange(len(names)); width=.24
fig,ax=plt.subplots(figsize=(10.5,5.8))
ax.bar(x-width,trust,width,label='公共信任',color='#2b6388'); ax.bar(x,false,width,label='错误认证率',color='#aa645c'); ax.bar(x+width,survive,width,label='24月存续率',color='#4f7b67')
ax.set_xticks(x,names); ax.set_ylim(0,1); ax.set_ylabel('比例'); ax.set_title('图5  20,000次合成压力测试：开放复现网络优于“继续开仓库”或“官方徽章”',weight='bold',pad=12)
ax.legend(ncol=3,loc='upper left'); ax.grid(axis='y',alpha=.2); ax.spines[['top','right']].set_visible(False)
for container in ax.containers: ax.bar_label(container,fmt='%.2f',fontsize=8,padding=2)
fig.tight_layout(); fig.savefig(FIG/'fig5_strategy_simulation.png',dpi=220); plt.close(fig)

# 6 roadmap
fig,ax=plt.subplots(figsize=(12,6.2)); ax.set_xlim(0,24); ax.set_ylim(0,6.5); ax.set_xlabel('月份'); ax.set_yticks([]); ax.grid(axis='x',alpha=.18)
items=[('0-30天：主张注册与解包源码',0,1,5.6),('31-90天：首轮外部复现与Break DIKWP',1,3,4.7),('3-6月：两套实现与互操作测试',3,6,3.8),('6-12月：年度结算与失败公共库',6,12,2.9),('12-18月：真实场景验证与受影响者审计',12,18,2.0),('18-24月：联邦证据节点与外部治理',18,24,1.1)]
colors=['#244f70','#326889','#4a7890','#668999','#809aa4','#9aa9ae']
for (label,start,end,y),c in zip(items,colors):
    ax.add_patch(FancyBboxPatch((start,y-.3),end-start,.6,boxstyle='round,pad=.02,rounding_size=.08',facecolor=c,edgecolor='none'))
    ax.text((start+end)/2,y,label,ha='center',va='center',color='white',fontsize=9.5,weight='bold')
ax.set_title('图6  24个月路线：把“发布”改造成“被外部否证仍能进化”的长期制度',weight='bold',pad=12)
ax.spines[['top','right','left']].set_visible(False)
fig.tight_layout(); fig.savefig(FIG/'fig6_roadmap.png',dpi=220); plt.close(fig)

# 7 governance separation
fig,ax=plt.subplots(figsize=(11,6.5)); ax.set_xlim(0,11); ax.set_ylim(0,7); ax.axis('off')
roles=[('原创与出处局','确认谁提出/何时提出',(1.6,5.4)),('主张编辑组','冻结范围与反证条件',(5.5,5.7)),('独立复现节点','运行与生成新数据',(9.4,5.4)),('红队与反例委员会','奖励失败与最小反例',(2.2,2.6)),('互操作工作组','比较独立实现',(5.5,1.5)),('公共结算委员会','更新证据状态',(8.8,2.6))]
for idx,(t,d,(x,y)) in enumerate(roles):
    c=['#e8eff4','#e6e9f2','#e2eee9','#f2e4df','#e6edf3','#e9e6ef'][idx]
    ax.add_patch(FancyBboxPatch((x-1.15,y-.62),2.3,1.24,boxstyle='round,pad=.04,rounding_size=.12',facecolor=c,edgecolor='#587181'))
    ax.text(x,y+.18,t,ha='center',va='center',fontsize=10.5,weight='bold'); ax.text(x,y-.25,d,ha='center',va='center',fontsize=8.3,color='#55636b')
# arrows
pairs=[(0,1),(1,2),(2,5),(3,5),(4,5),(1,3),(2,4)]
for a,b in pairs:
    x1,y1=roles[a][2]; x2,y2=roles[b][2]
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=11,color='#778a96',connectionstyle='arc3,rad=.08',shrinkA=50,shrinkB=50))
ax.text(5.5,6.65,'图7  可信不是由“官方认证中心”单点签发，而由相互制衡的独立角色共同生成',ha='center',fontsize=15,weight='bold')
ax.text(5.5,.38,'硬规则：出处可由作者确认；证据状态不能由作者单独签发；部署授权由MANDATE²另行处理。',ha='center',fontsize=10,color='#3c4b54')
fig.tight_layout(); fig.savefig(FIG/'fig7_governance_roles.png',dpi=220,bbox_inches='tight'); plt.close(fig)

# 8 ecosystem integration
fig,ax=plt.subplots(figsize=(12,7)); ax.set_xlim(-6,6); ax.set_ylim(-4.7,4.7); ax.axis('off')
ax.add_patch(Circle((0,0),1.25,facecolor='#234f70',edgecolor='white')); ax.text(0,.15,'CREDENCE²',ha='center',va='center',color='white',fontsize=16,weight='bold'); ax.text(0,-.4,'公共证据交易层',ha='center',color='white',fontsize=9)
mods=[('MESH²','语义分歧/残差',(-4.3,2.7)),('AION','概率更新/结算',(0,4.0)),('PACT','首个复现旗舰',(4.3,2.7)),('PRAXIS²','证据转行动',(4.5,-2.4)),('MANDATE²','行动授权边界',(0,-4.0)),('StandardForge','E5后标准化',(-4.5,-2.4)),('TrustPassport','拆成出处/证据双护照',(-5.0,.1)),('EIR/StewardOps','资源与节点运营',(5.0,.1))]
for t,d,(x,y) in mods:
    ax.add_patch(FancyBboxPatch((x-1.05,y-.55),2.1,1.1,boxstyle='round,pad=.04,rounding_size=.13',facecolor='#edf3f6',edgecolor='#5a7586'))
    ax.text(x,y+.15,t,ha='center',weight='bold',fontsize=10.5); ax.text(x,y-.23,d,ha='center',fontsize=8.2,color='#55636b')
    ax.add_patch(FancyArrowPatch((0,0),(x*.72,y*.72),arrowstyle='<|-|>',mutation_scale=10,color='#7a8e99',shrinkA=45,shrinkB=50))
ax.set_title('图8  CREDENCE²不是第188个孤立仓库，而是连接现有系统的横向公共证据内核',fontsize=15,weight='bold',pad=12)
fig.tight_layout(); fig.savefig(FIG/'fig8_integration_map.png',dpi=220); plt.close(fig)

print('figures',len(list(FIG.glob('*.png'))))
