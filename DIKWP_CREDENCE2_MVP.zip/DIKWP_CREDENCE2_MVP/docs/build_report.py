from __future__ import annotations

import json
import re
from pathlib import Path
from datetime import date
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.dml import MSO_THEME_COLOR_INDEX

ROOT=Path('/mnt/data/DIKWP_CREDENCE2_MVP')
OUT=Path('/mnt/data/DIKWP_CREDENCE2_Independent_Replication_Public_Evidence_System_Report_CN.docx')
FIG=ROOT/'docs'/'figures'
summary=json.loads((ROOT/'outputs/summary.json').read_text(encoding='utf-8'))
repos=json.loads((ROOT/'data/repo_snapshot.json').read_text(encoding='utf-8'))
claims=json.loads((ROOT/'data/claims.json').read_text(encoding='utf-8'))

BLUE='1F4E6D'; MIDBLUE='2B6388'; LIGHTBLUE='EAF2F7'; PALE='F5F8FA'; DARK='17232D'; GREY='5D6B75'; LINE='D8E0E6'; RED='8B3D45'; GREEN='2F6F5E'; GOLD='8E6A24'


def set_cell_shading(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr()
    shd=tcPr.find(qn('w:shd'))
    if shd is None:
        shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)


def set_cell_margins(cell, top=80, start=100, bottom=80, end=100):
    tc=cell._tc; tcPr=tc.get_or_add_tcPr(); tcMar=tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar=OxmlElement('w:tcMar'); tcPr.append(tcMar)
    for m,v in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node=tcMar.find(qn(f'w:{m}'))
        if node is None: node=OxmlElement(f'w:{m}'); tcMar.append(node)
        node.set(qn('w:w'),str(v)); node.set(qn('w:type'),'dxa')


def set_repeat_table_header(row):
    trPr=row._tr.get_or_add_trPr(); tblHeader=OxmlElement('w:tblHeader'); tblHeader.set(qn('w:val'),'true'); trPr.append(tblHeader)


def set_row_cant_split(row):
    trPr=row._tr.get_or_add_trPr()
    node=trPr.find(qn('w:cantSplit'))
    if node is None:
        node=OxmlElement('w:cantSplit'); node.set(qn('w:val'),'true'); trPr.append(node)


def set_run_font(run, east='Noto Serif CJK SC', latin='Aptos', size=None, bold=None, color=None):
    run.font.name=latin
    run._element.rPr.rFonts.set(qn('w:eastAsia'),east)
    if size: run.font.size=Pt(size)
    if bold is not None: run.bold=bold
    if color: run.font.color.rgb=RGBColor.from_string(color)


def set_para_spacing(p, before=0, after=6, line=1.35):
    pf=p.paragraph_format; pf.space_before=Pt(before); pf.space_after=Pt(after); pf.line_spacing=line


def add_hyperlink(paragraph, text, url, color='2B6388', underline=True):
    part=paragraph.part
    r_id=part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True)
    hyperlink=OxmlElement('w:hyperlink'); hyperlink.set(qn('r:id'),r_id)
    new_run=OxmlElement('w:r'); rPr=OxmlElement('w:rPr')
    c=OxmlElement('w:color'); c.set(qn('w:val'),color); rPr.append(c)
    if underline:
        u=OxmlElement('w:u'); u.set(qn('w:val'),'single'); rPr.append(u)
    rFonts=OxmlElement('w:rFonts'); rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC'); rFonts.set(qn('w:ascii'),'Aptos'); rPr.append(rFonts)
    new_run.append(rPr); t=OxmlElement('w:t'); t.text=text; new_run.append(t); hyperlink.append(new_run); paragraph._p.append(hyperlink)
    return hyperlink


def add_page_number(paragraph):
    paragraph.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=paragraph.add_run(); fldChar1=OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'),'begin')
    instrText=OxmlElement('w:instrText'); instrText.set(qn('xml:space'),'preserve'); instrText.text=' PAGE '
    fldChar2=OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'),'end')
    run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2); set_run_font(run,east='Noto Sans CJK SC',size=9,color=GREY)


def add_image_alt(inline_shape, title, descr):
    docPr=inline_shape._inline.docPr
    docPr.set('title', title); docPr.set('descr', descr)


def add_body(doc, text, bold_prefix=None, indent=True, after=7):
    p=doc.add_paragraph(style='Body Text')
    if indent: p.paragraph_format.first_line_indent=Cm(0.74)
    if bold_prefix and text.startswith(bold_prefix):
        r=p.add_run(bold_prefix); set_run_font(r,bold=True)
        r=p.add_run(text[len(bold_prefix):]); set_run_font(r)
    else:
        r=p.add_run(text); set_run_font(r)
    set_para_spacing(p,after=after,line=1.42)
    return p


def add_bullet(doc, text, level=0, color=None):
    style='List Bullet' if level==0 else 'List Bullet 2'
    p=doc.add_paragraph(style=style); r=p.add_run(text); set_run_font(r,color=color)
    set_para_spacing(p,after=3,line=1.28); return p


def add_number(doc, text, level=0):
    style='List Number' if level==0 else 'List Number 2'
    p=doc.add_paragraph(style=style); r=p.add_run(text); set_run_font(r); set_para_spacing(p,after=3,line=1.28); return p


def add_callout(doc, title, body, fill=LIGHTBLUE, accent=MIDBLUE):
    t=doc.add_table(rows=1,cols=1); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False; t.columns[0].width=Cm(16.2); set_repeat_table_header(t.rows[0]); set_row_cant_split(t.rows[0])
    c=t.cell(0,0); set_cell_shading(c,fill); set_cell_margins(c,160,220,160,220)
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(3)
    r=p.add_run(title); set_run_font(r,east='Noto Sans CJK SC',bold=True,size=12,color=accent)
    p2=c.add_paragraph(); p2.paragraph_format.space_after=Pt(0); p2.paragraph_format.line_spacing=1.35
    r=p2.add_run(body); set_run_font(r,size=10.5)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t


def add_figure(doc, filename, caption, alt, width=15.8):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    shape=p.add_run().add_picture(str(FIG/filename),width=Cm(width)); add_image_alt(shape,caption,alt)
    cp=doc.add_paragraph(); cp.alignment=WD_ALIGN_PARAGRAPH.CENTER; set_para_spacing(cp,after=8,line=1.1)
    r=cp.add_run(caption); set_run_font(r,east='Noto Sans CJK SC',size=9.2,color=GREY)


def add_table(doc, headers, rows, widths=None, font_size=8.6, header_fill=BLUE):
    table=doc.add_table(rows=1,cols=len(headers)); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.style='Table Grid'
    hdr=table.rows[0]; set_repeat_table_header(hdr); set_row_cant_split(hdr)
    for i,h in enumerate(headers):
        c=hdr.cells[i]; c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER; set_cell_shading(c,header_fill); set_cell_margins(c)
        p=c.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run(str(h)); set_run_font(r,east='Noto Sans CJK SC',bold=True,size=font_size,color='FFFFFF')
    for row in rows:
        new_row=table.add_row(); set_row_cant_split(new_row); cells=new_row.cells
        for i,val in enumerate(row):
            c=cells[i]; c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER; set_cell_margins(c)
            p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(0); p.paragraph_format.line_spacing=1.15
            r=p.add_run(str(val)); set_run_font(r,size=font_size)
    if widths:
        for row in table.rows:
            for i,w in enumerate(widths): row.cells[i].width=Cm(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return table


def add_equation(doc, text):
    t=doc.add_table(rows=1,cols=1); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False; t.columns[0].width=Cm(15.2); set_repeat_table_header(t.rows[0]); set_row_cant_split(t.rows[0])
    c=t.cell(0,0); set_cell_shading(c,'F2F4F5'); set_cell_margins(c,130,180,130,180)
    p=c.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run(text); set_run_font(r,east='Noto Sans Mono CJK SC',latin='Consolas',size=10,bold=True,color=DARK)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)


def page_break(doc):
    doc.add_page_break()


def heading(doc, text, level=1):
    p=doc.add_heading(text,level=level); set_para_spacing(p,before=8 if level==1 else 4,after=6,line=1.15)
    return p


doc=Document()
sec=doc.sections[0]
sec.top_margin=Cm(2.2); sec.bottom_margin=Cm(2.0); sec.left_margin=Cm(2.25); sec.right_margin=Cm(2.05)
sec.header_distance=Cm(0.9); sec.footer_distance=Cm(0.9)

# Core properties
props=doc.core_properties; props.title='DIKWP-CREDENCE²开放主张、独立复现、反证悬赏、互操作与公共可信扩散系统'; props.subject='段玉聪GitHub生态关键补全系统'; props.author='OpenAI'; props.keywords='DIKWP, open source, replication, evidence, interoperability, public trust'; props.comments='Public GitHub snapshot 2026-07-17; research and governance prototype.'

styles=doc.styles
normal=styles['Normal']; normal.font.name='Aptos'; normal._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC'); normal.font.size=Pt(10.5)
body=styles['Body Text']; body.font.name='Aptos'; body._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC'); body.font.size=Pt(10.5)
for name,size,color in [('Title',26,BLUE),('Subtitle',13,GREY),('Heading 1',17,BLUE),('Heading 2',13.5,MIDBLUE),('Heading 3',11.5,DARK)]:
    s=styles[name]; s.font.name='Aptos Display'; s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC'); s.font.size=Pt(size); s.font.color.rgb=RGBColor.from_string(color); s.font.bold=True
styles['Heading 1'].paragraph_format.keep_with_next=True; styles['Heading 2'].paragraph_format.keep_with_next=True; styles['Heading 3'].paragraph_format.keep_with_next=True
for liststyle in ['List Bullet','List Bullet 2','List Number','List Number 2']:
    s=styles[liststyle]; s.font.name='Aptos'; s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC'); s.font.size=Pt(10.2)

# Header/footer
header=sec.header.paragraphs[0]; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT; r=header.add_run('DIKWP-CREDENCE² · 公共证据与独立复现系统'); set_run_font(r,east='Noto Sans CJK SC',size=8.7,color=GREY)
footer=sec.footer.paragraphs[0]; add_page_number(footer)

# Cover
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(44); p.paragraph_format.space_after=Pt(16)
r=p.add_run('DIKWP-CREDENCE²'); set_run_font(r,east='Noto Sans CJK SC',latin='Aptos Display',size=32,bold=True,color=BLUE)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; set_para_spacing(p,after=10,line=1.1)
r=p.add_run('开放主张、独立复现、反证悬赏、互操作与公共可信扩散系统'); set_run_font(r,east='Noto Sans CJK SC',size=20,bold=True,color=DARK)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; set_para_spacing(p,after=24,line=1.2)
r=p.add_run('段玉聪GitHub生态从“原创密度”走向“公共事实基础设施”的关键补全'); set_run_font(r,east='Noto Sans CJK SC',size=13,color=GREY)

add_callout(doc,'核心命题','段玉聪现有生态已经拥有理论、预测、生命、意识、治理、标准化、出处认证和试点工具；真正缺失的是一种允许外部团队在不依赖作者解释的条件下复现、反驳、重新实现和公开结算的公共证据协议。开源代码不是开放证据，作者可运行不是独立复现，官方认证不是独立可信。',fill='E7F0F5',accent=BLUE)

p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(34)
for line,size,bold in [('系统设计报告与可运行MVP说明',12,True),('Version 1.0 · GitHub公开快照日期：2026-07-17',10,False),('研究、标准与治理原型；不构成对任何仓库的官方认证',9.5,False)]:
    r=p.add_run(line+'\n'); set_run_font(r,east='Noto Sans CJK SC',size=size,bold=bold,color=GREY if not bold else DARK)
page_break(doc)

# Executive summary
heading(doc,'执行摘要',1)
add_body(doc,'截至2026年7月17日，段玉聪公开GitHub页面显示约187个公开仓库、208个Stars、308名关注者，个人简介集中于DIKWP、人工意识与语义计算。仓库版图已从早期语义与人工意识研究扩展到预测、社会韧性、生命判定、意识迁移、长生、跨文明沟通、智能体治理、教育、医疗、交通、标准化、出处认证和产业试点。这个生态的首要特征不是“方向不够”，而是方向极其丰富、原型生成速度极高。',bold_prefix='截至2026年7月17日，')
add_body(doc,'公开页面抽样还显示出一种高度一致的交付形态：许多代表性仓库只有少量提交，根目录常见README、LICENSE和一个完整ZIP交付包；外部Issue、Pull Request、Fork和版本化Release仍较少。DIKWP-MESH²、DIKWP-EIR-Mesh等仓库公开显示3次提交、0个Fork、0个Issue和0个Pull Request，且没有Release；PACT同样只有3次提交和0个Fork，但已经发布1个Release，并把问题压缩为可证伪的Purpose与权限保持测试。这种差异极其重要：它说明段玉聪已经找到从“宏大体系”进入“窄问题、基准、版本、预注册”的正确方向，但尚未形成让外部组织持续验证和共同维护的制度。')
add_body(doc,'现有EIR-Mesh已经认识到仓库扩张、维护者不足和旗舰收敛问题；StewardOps处理生态运营；StandardForge处理标准化档案；OriginMoat与TrustPassport处理原创归属、出处、符合性和生态认证；PRAXIS²处理从思想到行动；MANDATE²处理公共行动合法授权。它们仍共同缺少一层：谁可以独立验证主张，如何定义“复现成功”，失败结果如何永久保存，反例如何得到奖励，两套独立实现如何证明互操作，证据何时因版本和环境变化而过期，以及一个外部Fork能否在证据上超过官方仓库。')
add_callout(doc,'最终战略判断','下一阶段最关键的公共产品不是第188个主题仓库，而是一个“公共证据交易层”。它要把每个宏大系统拆成可结算的Claim Contract，使源码、数据、环境、输出和限制形成Repro Capsule；让独立团队提交Replication Attempt；让反方提交最小Counterexample；让至少两套独立实现通过Interoperability Report；最终形成按具体主张签发、会到期、可降级、可被外部推翻的Evidence Passport。',fill='F1F6F9',accent=BLUE)
add_body(doc,'本报告据此设计DIKWP-CREDENCE²。系统不颁发“DIKWP官方真理徽章”，而是维护E0至E7证据状态：从叙事主张、可检查工件、作者环境可复现、独立复现、反证稳健、独立互操作实现、真实场景验证到公共基础设施。状态只属于一个具体版本的具体主张，不属于整个仓库、作者或品牌；出处证明与真实性证明分账；软件安全与科学有效性分账；证据成熟度与公共部署授权分账。')
add_body(doc,'MVP已实现15个代表性仓库快照、5份示例Claim Contract、复现胶囊、独立性折扣、反例账本、互操作报告、E0-E7状态机、哈希证据账本、20,000次合成战略压力测试、离线仪表盘和10项自动测试。演示中，PACT主张因合成的独立复现、对抗测试和两套互操作实现进入E5；MESH主张保持在E2；AION尚处E0；LifeClosure和ProofLedger处E1，其中ProofLedger被一个可复现反例显著下调。上述结果仅用于验证机制，不是对真实仓库的正式评价。')

heading(doc,'报告范围与方法边界',2)
add_bullet(doc,'GitHub分析基于2026-07-17无需登录可见的个人主页、六页仓库列表及若干代表性仓库页面；未使用私有流量、克隆统计、下载统计或作者后台数据。')
add_bullet(doc,'公开页面动态组件偶有加载失败；对没有明确显示的字段一律记为“未知”，不将未知静默计为零。')
add_bullet(doc,'仓库抽样是战略诊断，不是完整代码审计、安全审计或学术同行评审。')
add_bullet(doc,'报告中的概率、后验与20,000次模拟为合成参数，用于检验制度结构，不是现实成功率预测。')
add_bullet(doc,'本系统不改变PRAXIS²和MANDATE²的职责：证据可以支持行动，但不能自行授予公共权力。')

page_break(doc)
heading(doc,'一、对现有GitHub内容与目标的再分析',1)
heading(doc,'1.1 真正的总体目标：用开放系统争夺未来的定义权，但不把定义权私有化',2)
add_body(doc,'从仓库命名和定位可以看出，段玉聪的核心目标并非只做一个软件产品，而是试图以DIKWP为横向语义框架，把人工智能快速发展产生的未知问题提前编译成可观察、可讨论、可治理和可行动的系统。仓库覆盖人工意识白盒评估、Purpose Contract、生命与意识边界、AI社会冲击、人的记忆主权、数字生命、未来文明、意图经济、公共治理、医疗教育和交通安全，显示出明确的“先搭建未来制度原型，再等待现实进入该问题”的战略。')
add_body(doc,'这种战略的长处是能够在主流制度尚未形成之前，提前提供词汇、对象、Schema、仪表盘和行动门。它使未来不完全由少数封闭模型公司、资本平台和监管部门单方面定义。然而，它也存在一个内生悖论：若所有概念、评价、标准、认证和官方注册都围绕原作者组织，开放系统可能在形式上开放、在认识论上仍然中心化。真正改变世界的开放基础设施必须允许外部主体证明原作者错了，允许外部实现优于官方实现，并允许原始概念在证据压力下被重写。')
add_body(doc,'附件《Defining Life: A Conversation》对这一点提供了深层启发。讨论者反复强调，生命不是被动对象，真正的生命过程会“推回”环境和规则，会改变自身适应方式、状态空间和观察者；Susan Stepney进一步指出，理解开放生命需要处理动态增长的状态空间、变化规则、自指与开放式变化。把这个洞见映射到开源共同体，可信生态也不能只由作者向外发布规则，而必须让外部复现、反例和地方实现反向改写主张、协议和标准。否则共同体只是被管理的工件集合，不是能够自我纠错和开放演化的公共系统。')

heading(doc,'1.2 六项已经形成的结构性优势',2)
for txt in [
'问题发现密度极高。仓库已经覆盖许多尚未形成成熟公共工具的主题，包括人工意识候选福利、Purpose安全、身份分叉、信息生命、社会AI红利和跨文明通信。',
'跨领域对象化能力强。很多仓库不是只写观点，而是进一步提出账本、合同、动作票据、状态机、Schema和离线仪表盘，使抽象问题具有工程入口。',
'离线优先和无API依赖降低了外部试用门槛。对于治理、教育和公共服务原型，这种交付策略能减少平台锁定和敏感数据外流。',
'已经出现自我收敛意识。EIR-Mesh明确提出Repo Atlas、Flagship Funnel、Release Gate、Maintainer Council和Reviewer Pool，说明生态已认识到“继续开仓库”不是无限可持续策略。',
'MESH²完成了关键理论纠偏。它把D、I、K、W、P视为平权、混合、互相修订的语义资源，并将完整25类DIKWP×DIKWP变换设为一等操作，为跨主体证据争议提供了正确底座。',
'PACT提供了最值得扩大的交付样板。它公开提出窄而可证伪的问题，提供配对场景、基线、Schema、预注册计划和Release，已经从“系统宣言”迈向“他人可以尝试打败的基准”。']:
    add_bullet(doc,txt)

add_figure(doc,'fig1_repo_landscape.png','图1  段玉聪GitHub代表性仓库的宏观能力版图（15仓库公开页面样本）','横向条形图，将15个代表性仓库归入语义与智能体保障、证据与标准、预测与组合管理、生命意识、公共治理和试点采用六类。')

heading(doc,'1.3 八项仍然阻碍世界级影响的证据缺口',2)
numbered=[
('主张粒度过大','很多仓库以一个完整“系统”作为最小单位，难以区分其中哪一条主张被证据支持、哪一条只是设计假设。'),
('源码可检查性不足','ZIP包适合一次性交付，却不利于逐文件Diff、持续集成、依赖审计、外部PR和逐步维护。'),
('作者复现与独立复现混淆','作者能够运行自己的原型只是最低条件，不能回答外部团队是否在独立环境、独立实现或独立数据上得到相似结论。'),
('出处认证与真实性认证混淆','OriginMoat、TrustPassport的归属保护很重要，但“确实来自段玉聪”并不等于“主张为真”或“系统有效”。'),
('标准文件先于互操作证据','StandardForge能够生成档案和符合性矩阵，但没有至少两套独立实现和互操作报告时，标准容易成为文档化愿望。'),
('失败没有形成公共资产','多数开源生态奖励成功Demo和新版本，失败复现、负结果、最小反例和撤销主张缺少同等持久的署名与资源。'),
('证据没有到期机制','前沿模型、依赖、数据和社会环境变化极快；一次通过不能永久覆盖新版本和新场景。'),
('外部主体无法在证据上超越官方分支','如果“官方”天然拥有最高信任等级，Fork就只能是从属版本，系统失去真正开放演化能力。')]
for i,(t,b) in enumerate(numbered,1): add_number(doc,f'{t}：{b}')

add_figure(doc,'fig2_trust_gap_chain.png','图2  从原创思想到公共标准的可信断裂链','八个连续阶段：原创思想、开源工件、作者复现、独立复现、反证稳健、互操作、场景验证和公共标准；关键断点位于作者复现与独立复现之间。')

heading(doc,'1.4 为什么现有“标准、护照、运营、行动、授权”系统仍不能替代CREDENCE²',2)
rows=[
('EIR-Mesh','收敛仓库、资源路由、旗舰漏斗','缺少按具体主张分配复现资源的成熟度账本'),
('StewardOps','生态运营、登记、日历、合作筛选','缺少独立复现节点的资质与冲突图'),
('StandardForge','标准化档案、符合性矩阵、认证草案','缺少两套独立互操作实现作为强制前置门'),
('OriginMoat','原创归属、官方价值与发布策略','归属保护不能评价主张真伪；可能与外部反证形成利益冲突'),
('TrustPassport','来源、符合性和生态认证','需要拆成Origin Passport与Evidence Passport两本账'),
('ProofLedger','主张—证据—来源关系','来源存在不等于证据语义支持；仍需独立复制和反事实检验'),
('PRAXIS²','把预测和理论编译为现实行动','行动前仍需知道其依据达到什么证据成熟度'),
('MANDATE²','谁授权、影响谁、如何申诉退出','合法授权不能替代技术和科学有效性；反之亦然'),
('PilotFactory','把用例编译为试点','可以运营E6验证，但不能兼任独立结算者')]
add_table(doc,['现有系统','已解决问题','仍缺少的证据功能'],rows,widths=[3.2,5.0,8.0],font_size=8.4)

page_break(doc)
heading(doc,'二、DIKWP-CREDENCE²的定位与基本定理',1)
heading(doc,'2.1 系统正式定义',2)
add_body(doc,'DIKWP-CREDENCE²是一个面向开源研究、智能体协议、人工意识评估、社会治理原型和未来公共基础设施的联邦证据系统。它把任何项目中的关键判断拆成可版本化、可反证、会到期的Claim Contract；把源码、环境、数据、执行命令、参考输出、SBOM和构建出处编译为Repro Capsule；让独立主体提交不同类型的Replication Attempt；让反方提交Counterexample；让多个实现通过Interop Report交换同一协议；最终由多主体公共结算产生Evidence Passport。')
add_body(doc,'“Credence”在这里不是信仰，也不是品牌声誉，而是一个带来源、独立性、反例、适用范围、时间衰减和禁止外推条件的证据状态。系统不尝试把所有知识压缩成单一真值分数，而是同时保存出处质量、计算复现、独立性、对抗稳健、互操作、场景外推、权利影响和治理成熟度。')

heading(doc,'2.2 七条基本定理',2)
for txt in [
'开源不等于开放证据。许可证允许复制代码，但不会自动提供可复现环境、数据、参考输出、反证条件和独立结论。',
'作者可运行不等于独立复现。同一团队、同一代码和同一数据的成功，只证明工件在原设定下可执行。',
'出处证明不等于真实性证明。Git提交、哈希和签名可以确认“谁在何时发布了什么”，不能确认其科学、政策或伦理主张为真。',
'符合性不等于有效性。系统可以完全符合一个Schema，却在现实中无效、伤害用户或无法跨情境迁移。',
'证据状态属于主张，不属于仓库。一个仓库可以同时包含E5协议、E2实现和E0宏大愿景。',
'标准必须建立在独立实现之上。至少两套彼此独立、能够互操作的实现，以及一组公开的负向测试，是进入标准化的最低门。',
'可信必须允许被否定。若作者或官方中心可以删除负结果、拒绝外部Fork升级，系统提供的是品牌管理而不是公共知识。']:
    add_number(doc,txt)

heading(doc,'2.3 与现有开源和科研规范的接口',2)
add_body(doc,'CREDENCE²不重新发明软件供应链安全。GitHub Artifact Attestations用于声明软件在何处、如何构建；SLSA提供从源代码到工件的供应链完整性框架；Reproducible Builds追求从相同源代码得到可独立验证的二进制；OpenSSF Scorecard提供自动化开源安全健康检查。这些机制解决“工件是不是由所声称的源和流程构建”，但仍不回答“工件中的科学或政策主张是否被独立支持”。')
add_body(doc,'在科研侧，CREDENCE²采用更精确的术语：Reproduction指同一问题、同一数据和同一分析；Robustness指同一数据但合理替代分析；Replication指独立数据或独立情境再次检验同一主张。FAIR原则要求数字资产可发现、可访问、可互操作和可复用；IETF长期强调rough consensus and running code，并在标准推进中要求独立且可互操作的实现报告。CREDENCE²把这些原则扩展到DIKWP跨领域主张，使“运行代码”与“公开反证”共同成为标准化前提。')

heading(doc,'三、系统对象：从README叙述到公共证据网络',1)
heading(doc,'3.1 Claim Contract：把宏大系统拆成可结算原子',2)
add_body(doc,'Claim Contract不是一句营销口号，而是对“在什么范围内、相对于什么基线、使用什么指标、满足什么条件、哪些观察会使主张失败、哪些结论禁止外推”的预先承诺。主张一旦冻结，作者不能在看到结果后静默改变成功标准；若语义范围发生实质改变，必须生成新的Claim ID和谱系关系。')
add_body(doc,'一个合格主张至少包含：唯一编号与版本、来源仓库、观察单位、适用范围、基线、主指标、效应下限、成功规则、反证条件、允许的数据和分析、禁止推断、风险边界、到期时间、DIKWP语义网以及作者利益冲突。对于人工意识、生命和社会治理主张，尤其需要写明“这个结果不证明什么”，以防止局部操作指标被扩张成存在论或公共权力结论。')
add_equation(doc,'Claim = ⟨scope, baseline, metric, success rule, falsifiers, prohibited inferences, expiry, DIKWP mesh⟩')

heading(doc,'3.2 Repro Capsule：让别人不需要作者口头解释也能运行',2)
add_body(doc,'Repro Capsule必须把“运行项目”从个人经验转为机器可读契约。其内容包括解包源码、精确提交哈希、依赖锁定、容器或环境描述、数据清单与许可证、随机种子、单命令运行、预计耗时、计算资源、参考输出与容差、已知失败、SBOM、构建签名和Artifact Attestation。仅上传一个ZIP并在README中写“打开index.html”，可以达到可试用，但尚不足以支持跨平台、跨版本和长期复现。')
add_body(doc,'对浏览器离线原型，复现胶囊还应包含浏览器版本、前端构建链、静态资源哈希、无网络模式证明、种子数据、截图基线和自动化交互测试。对政策和社会系统，则需要另外保存样本选择、参与者角色、权利边界、执行成本和环境条件，因为代码相同并不意味着制度结果相同。')

heading(doc,'3.3 Replication Attempt：六种不同检验不可混为一谈',2)
rows=[
('Reproduction','同代码、同数据、同分析','确认工件可执行和参考输出可重现'),
('Robustness','同数据、合理替代分析','确认结论不是单一参数或统计选择的产物'),
('Replication','独立团队、独立环境或独立数据','检验主张能否超出作者环境'),
('Adversarial','预注册攻击、边界输入、最小反例','主动寻找失败而不是证明成功'),
('Interoperability','两套以上独立实现交换数据/状态','检验规范是否真正可实现而非只可阅读'),
('Field Validation','真实用户、组织、成本、副作用与申诉','检验现实有效性和外部性')]
add_table(doc,['尝试类型','关键差异','主要回答的问题'],rows,widths=[3.0,5.0,8.2],font_size=8.5)
add_body(doc,'所有Replication Attempt必须披露组织、资金、与作者关系、预注册状态、原始输出、协议偏离和无效原因。独立性不是一个简单“是/否”标签，而是由机构、资金、实现、数据、基础设施和人员重叠组成的图。系统对同一组织、同一代码派生和同一数据源的多次结果进行相关性折扣，防止把一个证据复制成十个独立证据。')

heading(doc,'3.4 Counterexample与Failure Commons：把“打败系统”变成公共贡献',2)
add_body(doc,'CREDENCE²把最小反例视为一等研究产出。Counterexample必须说明最小输入、期望行为、实际行为、复现命令、影响范围、严重性和是否影响主张核心。反例可以只推翻一个边界外推，也可以迫使整个主张降级；无论作者是否接受，经过复现的反例都进入不可静默覆盖的Failure Commons。')
add_body(doc,'系统建议建立“Break DIKWP”悬赏：奖励无法复现、反事实失败、语义歧义、偏差、权限绕过、隐写、跨实现不兼容、真实场景伤害和不当外推。奖励不以“证明作者错”为唯一条件，而以反例的最小性、可复现性、范围清晰度和修复价值计分。这样，外部批评者不再只是评论区参与者，而成为正式知识生产者。')

heading(doc,'3.5 Interoperability Profile：标准前必须先有多种实现',2)
add_body(doc,'一个协议只有在不同团队可以独立阅读规范、编写实现、交换同一消息并对错误输入给出一致处理时，才开始接近公共标准。Interop Report需要列出实现组织、语言与平台、功能矩阵、负向测试、交换往返次数、无法兼容的语义差异和仍需保留的扩展点。')
add_body(doc,'CREDENCE²建议把StandardForge的入口门改为E5：没有两套独立实现，不生成“标准候选”认证，只生成“研究草案”；没有负向互操作测试，不进入稳定版本；没有外部维护者，不进入公共基础设施。官方实现不能作为唯一规范解释者，规范文本与参考实现必须可被外部实现反向纠错。')

add_figure(doc,'fig4_claim_evidence_mesh.png','图4  Claim Contract周围的DIKWP证据网','中心主张与D、I、K、W、P、反例失败节点双向连接，外部独立复现、互操作、场景参与者和红队共同改变主张状态。')

page_break(doc)
heading(doc,'四、DIKWP网状语义如何进入证据系统',1)
heading(doc,'4.1 证据不是D到P的单向流水线',2)
add_body(doc,'CREDENCE²继承MESH²的关键纠偏：D、I、K、W、P是平权、混合、相互生成和相互修订的语义资源。一个“Purpose Contract降低越权”的主张，不是从数据逐层上升到目的；相反，Purpose决定应采集哪些越权数据，失败数据可能迫使Purpose改变，知识模型会改变信息分段，权利判断会要求新增数据，新的利益相关者Purpose也会重写成功标准。')
add_body(doc,'因此，每份Claim Contract携带一个DIKWP混合向量和实际调用的变换路径。复现者可以选择不同路径检验同一主张：P→D检查目的选择是否导致数据偏差，D→P检查行为证据是否支持目的推断，W→D检查权利原则是否要求新观测，K→I检查不同理论如何改变特征抽取，P→P检查目标是否被结果压力事后重写。')
add_equation(doc,'Evidence update is a mesh: {D,I,K,W,P} × {D,I,K,W,P} × observer × context × time × provenance')

heading(doc,'4.2 多观察者语义差异必须先保存，再尝试拼接',2)
add_body(doc,'独立复现经常不是简单得到“同样数字”，而是不同团队对观察单位、边界、成功标准和禁止外推存在不同理解。CREDENCE²不把这些差异视为噪声，而把它们保存为局部语义截面：哪些关系跨主体稳定，哪些只在特定理论或尺度成立，哪些构成真正冲突，哪些是当前无法翻译的残差。')
add_body(doc,'这对生命、意识和公共治理尤其重要。一个系统是否“具有持续身份”、一项社会试点是否“公平”、一个Purpose是否“被保持”，都可能依赖观察尺度和主体位置。系统允许多个任务索引合同并存：研究合同、福利合同、法律合同和部署合同可以共享证据，但不得互相偷换。')

heading(doc,'4.3 外部反例是系统“推回规则”的方式',2)
add_body(doc,'生命研究附件中的“push back”观点可以被严格转化为制度原则：如果一个开放系统只能接受按照作者预设规则产生的支持结果，却不能让外部世界改变它的成功标准、状态空间和版本谱系，它并不具备真正的开放演化。CREDENCE²要求每个状态升级都同时开放降级路径；一条新的高质量反例可以把E5主张降回E3，也可以触发分叉为两个范围更窄的新主张。')
add_body(doc,'这种设计不会导致相对主义。相反，它使争议变得更精确：不是争论“DIKWP是否正确”，而是问“PACT-C001 v0.1.0在什么场景、相对什么基线、以什么指标得到多大效应；哪个独立团队在何种偏离下复现；什么最小反例限制了结论”。宏大理论通过一组可被现实持续选择的主张谱系逐步获得可信度。')

heading(doc,'五、E0-E7证据状态与多轴Evidence Passport',1)
add_figure(doc,'fig3_evidence_states.png','图3  E0-E7证据状态阶梯','八级证据状态从叙事主张到公共基础设施；强调状态属于具体主张。')
rows=[
('E0 叙事主张','问题有价值，但尚未冻结范围、基线、指标和反证','README观点、路线图、愿景'),
('E1 可检查工件','源码/数据/协议可阅读，来源和版本可追踪','解包源码、许可证、Claim ID'),
('E2 作者环境可复现','同一工件在声明环境下产生参考输出','CI、锁定环境、参考输出'),
('E3 独立复现','至少一个独立团队在独立环境或数据上支持主张','预注册报告、原始输出、冲突披露'),
('E4 反证稳健','经对抗测试、替代分析和最小反例挑战后仍保留主效应','红队结果、边界条件、失败库'),
('E5 独立互操作实现','至少两套独立实现通过功能与负向互操作','实现矩阵、往返交换、差异报告'),
('E6 真实场景验证','真实组织和受影响者参与，成本、副作用和申诉得到结算','试点、权利审计、外部结算'),
('E7 公共基础设施','创始人退出仍可维护，多节点、多场景、替代运营者存在','公共托管、持续发布、外部治理')]
add_table(doc,['状态','最低含义','典型证据'],rows,widths=[3.0,7.4,5.8],font_size=8.2)

heading(doc,'5.1 状态不是总分，护照必须保留七维向量',2)
add_body(doc,'为了防止一个高总分掩盖关键缺陷，Evidence Passport同时显示七个维度：Provenance出处与构建来源、Reproducibility计算复现、Independence独立性、Adversarial Robustness反证稳健、Interoperability互操作、Field Validity场景有效、Governance公共维护。E状态只是最低门槛的压缩视图，任何使用者都可以查看完整向量和反例。')
add_body(doc,'例如一个主张可能拥有完美构建出处和作者复现，却没有独立性；另一个主张可能在真实场景有效，却没有可移植实现；第三个主张可能有两套互操作代码，但其社会权利影响不可接受。它们不能被一个“85分可信”概括。')

heading(doc,'5.2 概率更新与相关性折扣',2)
add_body(doc,'MVP采用保守的示例贝叶斯更新。每条证据的对数似然比由独立性、设计质量、语境匹配、来源完整性和新鲜度共同加权；同一组织、同一实现或同一数据的重复结果会被相关性折扣。正式项目必须为不同领域预注册自己的似然模型，不能把MVP系数当作通用科学规律。')
add_equation(doc,'log O(H|E) = log O(H) + Σᵢ wᵢ · log LRᵢ，wᵢ = independence × design × context × provenance × freshness × correlation discount')
add_body(doc,'负结果不等于自动判死刑。若一次反例只影响边界情境，系统可以缩小主张范围；若反例证明核心效应不存在，则主张状态和后验同时下降；若协议偏离严重，结果可标记为invalid但仍保留。所有判断必须说明为什么，而不是通过删除测试使仪表盘重新变绿。')

heading(doc,'5.3 证据到期与版本失效',2)
add_body(doc,'每份主张和护照都必须设定到期时间。模型大版本、依赖、数据生成过程、关键Schema、法律环境或目标人群发生实质变化时，历史证据不能自动继承。系统通过兼容性矩阵决定证据是完全继承、折扣继承还是失效。')
add_equation(doc,'freshness(t) = exp(-λ·Δt) × version_compatibility × context_compatibility')
add_body(doc,'这对GPT等前沿模型相关仓库尤为重要：一个在2026年模型上通过的Purpose保持测试不能永久证明2030年自主智能体安全；一个在合成场景通过的社会兜底算法不能直接证明不同地区现实有效。证据到期不是否定历史贡献，而是防止旧证据成为新系统的护身符。')

page_break(doc)
heading(doc,'六、独立性、治理与反中心化设计',1)
heading(doc,'6.1 “独立”必须由关系图表示',2)
add_body(doc,'外部团队并不因为名称不同就自动独立。CREDENCE²记录机构、资金、人员、代码、数据、云基础设施、指标设计和作者咨询关系。两个团队若使用同一核心代码和同一数据，只能算实现复现；若使用不同代码但由作者提供未公开调参，也不能视为完全独立；若由作者资助但预注册、公开原始输出并由第三方结算，可以获得部分独立权重，而不是简单排除。')
add_body(doc,'独立性图的目的不是制造纯洁性门槛，而是让使用者知道证据真正来自多少个相对独立的因果源。系统也防止“外包式独立”：作者选择友好团队、提供全部分析脚本，再把结果包装为第三方认证。')

heading(doc,'6.2 六类角色必须分离',2)
add_figure(doc,'fig7_governance_roles.png','图7  CREDENCE²的角色分离与相互制衡','原创出处、主张编辑、独立复现、红队反例、互操作工作组和公共结算委员会六类角色。')
add_body(doc,'原创与出处局只确认来源和谱系；Claim Editor负责冻结主张但不能决定结算；Replication Node运行检验；Red Team主动寻找失败；Interop Working Group比较实现；Settlement Board更新状态和发布争议说明。对于E6以上主张，还必须加入受影响者代表和权利观察员。')
add_body(doc,'硬性禁止包括：作者单独给自己升级E状态；资金提供者决定成功；标准编写者兼任唯一互操作测试者；安全漏洞报告被用来压制科学反例；Origin Passport被宣传为真实性认证；负结果因“影响生态声誉”而被删除。')

heading(doc,'6.3 外部Fork可以成为更可信的参考实现',2)
add_body(doc,'CREDENCE²将“canonical repository”和“reference implementation”分开。官方仓库表示谱系和原创来源；参考实现由当前证据决定。若外部Fork具有更完整测试、更安全供应链、更高互操作性和更多独立维护者，它可以被公共结算委员会标记为当前参考实现，而不改变原创归属。')
add_body(doc,'这一机制是开放系统能否真正改变世界的试金石。若所有外部实现都必须向官方认证中心申请地位，生态最终仍然是中心化品牌联盟；若Fork可以在事实和工程上超越官方版本，生态才会产生真正的选择压力和长期生命力。')

heading(doc,'6.4 TrustPassport必须拆成两本护照',2)
rows=[
('Origin Passport','谁在何时提出、代码谱系、许可证、署名、商标和官方关系','作者或出处机构可以签发'),
('Evidence Passport','具体主张的E状态、独立复现、反例、互操作、场景验证、到期时间','必须由多主体证据网络签发')]
add_table(doc,['护照','回答的问题','签发权'],rows,widths=[3.3,8.6,4.3],font_size=8.5)
add_body(doc,'两本护照可以同时存在，但不得互相推导。一个非官方Fork可能拥有低Origin地位但更高Evidence状态；一个官方版本可能具有最强原创出处，却因缺少测试而停留在E1。对外宣传必须明确显示二者，防止“官方”被公众误解为“已被证明”。')

page_break(doc)
heading(doc,'七、软件供应链、开放科学与仓库结构改造',1)
heading(doc,'7.1 从ZIP交付转向可审阅主仓',2)
add_body(doc,'ZIP可以继续作为Release资产和离线交付物，但旗舰仓库必须在Git树中解包核心源码、Schema、测试、示例和文档。只有这样，外部参与者才能进行逐行审阅、提交小型PR、观察版本差异、运行依赖扫描和构建可重复工件。')
add_body(doc,'建议每个旗舰采用统一目录：/claims保存主张合同；/src保存实现；/spec保存协议；/repro保存复现胶囊；/tests保存正向和负向测试；/replications保存第三方结果；/counterexamples保存反例；/interop保存实现矩阵；/field保存真实试点；/governance保存角色、利益冲突和结算规则；/evidence保存护照和哈希账本。')

heading(doc,'7.2 Release Gate的最低自动化',2)
for txt in [
'所有Claim JSON通过Schema校验，主张变更必须生成新版本和变更说明。',
'单元测试、集成测试、负向测试和最小反例回归测试全部进入CI。',
'生成SBOM、依赖锁和OpenSSF Scorecard结果；安全分数低不自动否定研究主张，但必须披露。',
'构建产物生成Artifact Attestation和SHA-256清单，证明Release来自声明的工作流。',
'执行Repro Capsule的一命令运行并比较参考输出，记录平台差异。',
'发布CITATION.cff、SECURITY.md、CONTRIBUTING.md、CODEOWNERS和利益冲突声明。',
'Release Notes必须列出哪些主张升级、降级、过期或被反例限制。']:
    add_bullet(doc,txt)

heading(doc,'7.3 “开放科学”比“代码可下载”更严格',2)
add_body(doc,'FAIR原则要求数据、算法和工作流可发现、可访问、可互操作、可复用。对DIKWP而言，还需要“可反证”和“可归责”：使用者必须知道哪个输出由哪条主张、哪套实现、哪份数据、哪位操作者和哪次构建生成。')
add_body(doc,'对于无法公开的真实数据，可以发布合成数据、Schema、统计摘要、受控访问流程和独立审计证明；但不能以隐私为理由完全省略方法。对于高风险安全测试，可以延迟披露可利用细节，但不能永久压制结果。科学有效性、安全披露和个人隐私必须由不同流程协调。')

page_break(doc)
heading(doc,'八、现有仓库的收敛与证据迁移方案',1)
heading(doc,'8.1 不删除187个仓库，而是把它们转换为主张谱系',2)
add_body(doc,'大量仓库本身是段玉聪思想演化的历史记录，粗暴删除会损失谱系和先发价值。CREDENCE²建议每个旧仓库增加LINEAGE.md，标明它继承了哪些概念、被哪些后继替代、仍维护哪些主张、哪些主张已撤销，以及规范实现位于何处。')
add_body(doc,'仓库可以进入五种状态：Flagship（积极维护和外部复现）、Research Snapshot（固定研究快照）、Incubator（尚未冻结主张）、Merged（功能并入主仓）、Historic（只读历史）。只有Flagship允许对外宣称活跃产品；Incubator不得使用“认证”“标准”“已证明”等措辞。')

heading(doc,'8.2 资源分配应从“主题数量”转向“证据缺口”',2)
add_body(doc,'EIR-Mesh的Resource Router可以直接读取CREDENCE状态。资源不再按仓库新颖度平均分配，而是优先投入能跨越关键证据门的项目：从E1到E2需要工程解包和CI；从E2到E3需要外部团队和复现经费；从E3到E4需要红队和反例悬赏；从E4到E5需要第二实现；从E5到E6需要真实场景和权利审计。')
add_body(doc,'建议未来12个月的新增资源比例为：40%独立复现节点与奖金，20%第二实现和互操作，15%解包源码与供应链，15%真实场景结算，10%新概念研究。除安全紧急或经RFC批准外，暂停新建长期独立仓库90天。')

heading(doc,'8.3 15个代表性仓库的建议证据路由',2)
route_rows=[]
route_map={
'DIKWP-PACT-v0.1.0':'第一旗舰；冻结12条主张，招募3个外部节点，形成第二实现',
'DIKWP-MESH-':'建立多观察者公开数据集、线性基线和独立标注者；验证层级泄漏指标',
'DIKWP-EIR-Mesh-v1.0':'把E状态接入资源路由；优先资助跨门槛项目',
'DIKWP-AION':'注册50个短期可结算问题，等待真实到期记录而非模拟概率',
'DIKWP-ProofLedger-OS':'增加语义蕴含验证与反证边；以最小反例作为核心测试',
'DIKWP-AgentTrace-OS':'统一跨实现Trace Schema，支持回放和差异定位',
'DIKWP-StandardForge-OS':'将E5设为标准候选硬门',
'DIKWP-TrustPassport-OS':'拆分Origin/Evidence双护照',
'DIKWP-OriginMoat-OS':'仅处理出处与官方关系，不评价真伪',
'DIKWP-StewardOps-OS':'运营外部节点、冲突登记和证据到期日历',
'DIKWP-ConsciousAgent-BenchmarkLab-2026-V1':'将指标拆成可证伪主张，公开负例和跨模型复现',
'DIKWP-LifeClosure-OS':'跨生命科学/人工生命盲评，优先挑战病毒、休眠体、集体与数字生命',
'DIKWP-ARK':'进入影子场景和权利审计，不由模型自动决定福利',
'DIKWP-Civicode-Commons-OS':'让受影响群体参与成功指标和结算',
'DIKWP-PilotFactory-OS':'只做试点运营，外部Settlement Board负责E6结算'}
for r in repos: route_rows.append((r['repo'],r['category'],route_map.get(r['repo'],'注册主张并确定下一证据门')))
add_table(doc,['仓库','类别','下一步证据动作'],route_rows,widths=[5.0,3.5,7.7],font_size=7.8)

heading(doc,'九、三个首批公共复现旗舰',1)
heading(doc,'9.1 旗舰一：PACT Purpose与权限完整性公开挑战',2)
add_body(doc,'PACT是首个优先对象，因为它已经把问题压缩为一个可证伪问题，拥有72组配对合成场景、4个基线、Schema、预注册计划和版本Release。CREDENCE²建议把它从一个参考包升级为12个月开放复现计划。')
for txt in [
'冻结12条原子主张，其中核心主张只涉及Purpose和权限保持，不涉及意识存在。',
'提供Python参考实现、Rust或TypeScript独立实现，禁止复制核心决策代码。',
'建立500个公开场景，其中30%由外部红队贡献，至少100个为最小越权反例。',
'招募大学实验室、企业安全团队和独立开发者三类节点，披露资金关系。',
'按月发布失败榜单，不以作者平均分作为唯一成功指标。',
'达到E5后再由StandardForge形成Purpose Contract协议草案。']:
    add_bullet(doc,txt)
add_callout(doc,'第一年可结算目标','到2027年7月，至少两套独立实现通过90%以上功能矩阵和85%以上负向测试；至少三个独立团队提交可审计结果；核心主张在公开对抗测试后仍保持预注册效应。若未达成，PACT保留研究价值但不进入标准候选。',fill='EEF5F8',accent=BLUE)

heading(doc,'9.2 旗舰二：MESH²多观察者语义变换挑战',2)
add_body(doc,'MESH²的理论创新重要，但最容易陷入“指标由系统自身定义”的循环。旗舰计划必须建立外部任务：给定多主体冲突材料，比较完整网状DIKWP、固定线性DIKWP、普通知识图谱和大模型自由总结在残差保留、跨主体预测、反例敏感性、解释成本和操纵风险上的表现。')
add_body(doc,'数据集应包含生命、意识、公平、公共安全和个人身份五类概念，每类至少100个多观察者案例；标注者来自不同学科和利益位置；单一模型扮演多个观察者不能计作主体独立。系统必须公开“网状方法在哪些任务没有优势”，并允许新语义轴被反例撤销。')

heading(doc,'9.3 旗舰三：Human Continuity/ARK权利内核的真实影子验证',2)
add_body(doc,'第三旗舰不以证明宏大理论为目标，而选择当前可验证的权利功能：本人陈述与AI推测分离、数据可导出、代理可停用、人工复核、错误服务恢复、申诉不报复。项目先在影子模式运行，不改变真实福利、医疗、教育或身份决定。')
add_body(doc,'成功指标必须由使用者和受影响群体共同定义，包括误伤率、申诉时间、退出成功、数据迁移、理解成本和心理负担。PilotFactory可以运营试点，MANDATE²负责授权，CREDENCE²负责证据，二者不得由同一团队独立结算。')

heading(doc,'十、100天与24个月执行路线',1)
add_figure(doc,'fig6_roadmap.png','图6  DIKWP-CREDENCE²二十四个月实施路线','从主张注册、外部复现、互操作到真实场景和联邦治理的六阶段时间线。')
heading(doc,'10.1 第1-10天：冻结扩张，发布证据宪章',2)
for txt in [
'公开宣布90天内不新增长期孤立仓库，安全修复和已批准迁移除外。',
'创建DIKWP-CREDENCE规范主仓，发布Governance Minimum和E0-E7定义。',
'为PACT、MESH²、AION、LifeClosure、ProofLedger注册第一批Claim ID。',
'明确“官方”只表示出处，不表示证据状态。',
'建立外部复现者申请、利益冲突披露和负结果保护政策。']:
    add_number(doc,txt)

heading(doc,'10.2 第11-30天：解包源码与建立Release Gate',2)
for txt in [
'将12个旗舰ZIP核心源码解包进入Git树，保留ZIP作为Release资产。',
'补齐一命令运行、依赖锁、SBOM、参考输出、CITATION、SECURITY和CODEOWNERS。',
'为Claim Contract、Replication Attempt、Evidence Passport发布JSON Schema。',
'在GitHub Actions中验证主张合同、单元测试、负向测试和构建出处。',
'发布第一份“已知无法复现或尚未验证事项”清单。']:
    add_number(doc,txt)

heading(doc,'10.3 第31-60天：启动Break DIKWP与外部节点',2)
for txt in [
'招募6至12个外部复现节点，至少一半不与作者存在资金或组织关系。',
'为PACT和MESH²各发布10万元级或等值分层悬赏方案：复现、最小反例、第二实现、互操作和文档修复分别计奖。',
'预注册外部复现方法，禁止在看到作者输出后随意修改主指标。',
'建立Failure Commons，第一份负结果无论结论是否有利都必须公开。',
'邀请批评者进入Settlement Board，而不是只邀请支持者。']:
    add_number(doc,txt)

heading(doc,'10.4 第61-100天：完成第一次公共结算',2)
for txt in [
'完成PACT作者复现和至少一个独立复现；若失败，发布原因和主张降级。',
'完成MESH²线性基线对照和单一观察者虚假多主体反例。',
'发布Evidence Passport v0.1和Origin/Evidence双护照迁移方案。',
'把CREDENCE E状态接入EIR-Mesh Resource Router。',
'举行一次“我们被证明错在哪里”公开结算会，会议中心不是新系统发布，而是主张升级、降级和撤销。']:
    add_number(doc,txt)

heading(doc,'10.5 3-12个月：形成两套实现和年度结算',2)
add_body(doc,'在半年内，至少一个协议形成两套独立实现和互操作报告；在一年内，至少三个外部节点持续提交结果，一个主张达到E5，三个主张因反例缩小范围或降级。年度报告必须同时列出最佳成功和最严重失败，不允许只统计Stars、仓库数和演示数量。')

heading(doc,'10.6 12-24个月：形成联邦证据共同体',2)
add_body(doc,'第二年目标是让创始人不再是每项结论的必要中介。外部节点拥有主张提案权、反例登记权和状态异议权；Settlement Board多数成员来自外部；至少一个参考实现由非官方Fork承担；一项真实场景在当地重新授权并完成独立E6结算。')

page_break(doc)
heading(doc,'十一、指标体系：不再以仓库数和Stars作为核心成功标准',1)
heading(doc,'11.1 第一层：工件与供应链指标',2)
add_bullet(doc,'解包源码比例、可一命令运行比例、依赖锁定比例、SBOM覆盖、Artifact Attestation覆盖、Reproducible Build通过率。')
heading(doc,'11.2 第二层：主张质量指标',2)
add_bullet(doc,'拥有反证条件的主张比例、禁止外推字段完整率、主张到期率、事后改写次数、无效主张撤销率。')
heading(doc,'11.3 第三层：独立证据指标',2)
add_bullet(doc,'独立复现节点数、组织多样性、资金独立性、独立数据比例、负结果比例、最小反例数量、复现响应时间。')
heading(doc,'11.4 第四层：互操作与采用指标',2)
add_bullet(doc,'独立实现数、功能矩阵通过率、负向互操作通过率、跨语言和跨平台交换、真实场景数、受影响者申诉与退出。')
heading(doc,'11.5 第五层：共同体生命力指标',2)
add_bullet(doc,'非创始人维护者比例、外部PR合并率、创始人不在场的Release次数、Fork成为参考实现次数、失败结果被引用次数、协议日落和安全退出能力。')
add_callout(doc,'唯一不应追求的指标','“所有复现都成功”不是好指标。若一个证据系统的支持率接近100%，更可能说明主张过于模糊、外部团队不独立、失败被压制或评价门槛由作者控制。健康系统应同时产生确认、限制、否定和不可判定结果。',fill='F6EEEE',accent=RED)

heading(doc,'11.6 三年目标建议',2)
rows=[
('可检查工件','12个旗舰全部解包源码、CI、SBOM和签名Release'),
('主张注册','至少100份原子Claim Contract，其中20份完成到期结算'),
('外部节点','至少15个独立组织，覆盖技术、生命科学、社会政策和权利群体'),
('反例公共库','至少200个可复现最小反例，全部持久署名'),
('互操作','至少5个协议拥有两套独立实现，2个达到E5'),
('真实场景','至少3项E6验证，其中至少1项失败或停止也完整公开'),
('治理','外部成员占Settlement Board多数；创始人不拥有否决负结果的权力')]
add_table(doc,['指标','三年目标'],rows,widths=[4.0,12.2],font_size=8.8)

heading(doc,'十二、MVP运行结果与解释',1)
heading(doc,'12.1 仓库快照与主张示例',2)
add_body(doc,'MVP内置15个代表性公开仓库快照。只有MESH²、PACT和EIR-Mesh使用了公开仓库页面明确显示的Fork、Issue、PR、提交和Release字段；其他仓库只记录仓库列表可见的名称、定位和Stars，未知字段未计为零。这个设计用于示范“证据缺失必须显式为未知”，而不是制造伪精确评分。')
add_body(doc,'系统注册了PACT、MESH²、AION、LifeClosure和ProofLedger五份示例主张，并构造合成复现、反例和互操作事件。PACT-C001在演示中达到E5；MESH-C001达到E2；AION-C001保持E0；LifeClosure-C001与ProofLedger-C001处E1。ProofLedger的后验因“来源存在但正文不支持主张”的最小反例从0.67下降至约0.48，说明系统能够在保留出处的同时否定证据关系。')
claim_rows=[]
for r in summary['claim_rows']:
    claim_rows.append((r['claim_id'],r['source_repo'],r['state_label'],f"{r['posterior_probability']:.3f}",r['independent_attempts'],r['adversarial_attempts'],'是' if r['interoperable'] else '否','；'.join(r['caveats']) or '无'))
add_table(doc,['主张','来源','演示状态','示例后验','独立','对抗','互操作','主要限制'],claim_rows,widths=[2.6,3.5,3.2,1.5,1.1,1.1,1.2,5.0],font_size=7.4)
add_body(doc,'这些E状态不是对仓库现实质量的认证。真实升级必须由外部团队运行公开工件并提交原始结果；MVP中的独立团队名称、效应量和互操作实现均为合成示例。')

heading(doc,'12.2 20,000次策略压力测试',2)
add_figure(doc,'fig5_strategy_simulation.png','图5  四种生态策略的20,000次合成压力测试','比较继续仓库扩张、官方徽章、作者可复现和联邦复现网络在公共信任、错误认证率与24月存续率上的合成结果。')
sim_rows=[]
name_map={'repo_expansion':'继续仓库扩张','official_badge':'官方徽章中心','author_reproducible':'作者侧可复现','federated_credence':'联邦复现网络'}
for r in summary['simulation']:
    sim_rows.append((name_map[r['strategy']],r['median_public_trust'],r['median_independent_maintainers'],r['median_false_certification_rate'],r['median_interoperable_claims'],r['median_field_adoptions'],r['median_fragmentation'],r['survival_24m_rate']))
add_table(doc,['策略','公共信任','独立维护者','错误认证','互操作主张','场景采用','碎片化','24月存续'],sim_rows,widths=[3.4,1.8,1.8,1.8,1.8,1.8,1.8,1.8],font_size=8.0)
add_body(doc,'合成模拟中，联邦复现网络的中位公共信任0.727、错误认证率0.061、24个月存续率0.919，明显优于仓库扩张和官方徽章策略。模型人为赋予了独立复现、互操作和外部维护更高的长期反馈，因此不能作为现实因果证据；其价值在于显示制度假设：当项目允许反例、分散维护和相互验证时，更容易形成长期信任，而单纯增加发布数量会提高碎片化和维护风险。')

heading(doc,'12.3 运行证明',2)
add_bullet(doc,f"哈希证据账本：{summary['ledger']['count']}条事件，验证结果{'通过' if summary['ledger']['ok'] else '失败'}。")
add_bullet(doc,'自动测试：10项全部通过，覆盖独立复现门、作者复现限制、E5互操作、反例保留、账本篡改检测、DIKWP网归一化和互操作独立性。')
add_bullet(doc,'输出：repo_readiness.csv、claim_evidence_matrix.csv、strategy_simulation.csv、evidence_ledger.jsonl、summary.json与离线dashboard.html。')

heading(doc,'十三、关键风险与反捕获机制',1)
risks=[
('证据官僚化','主张合同过于复杂，使小团队无法参与','提供Lite模板；高风险主张才使用完整合同；资助文档维护'),
('复现表演化','外部团队只是重跑作者代码','独立性图、第二实现、独立数据和方法预注册'),
('负结果武器化','竞争者提交低质量攻击扰乱生态','质量门、可复现要求、范围说明；但不得因批评不友好而拒绝'),
('创始人失去合理署名','反中心化被误解为抹除原创','Origin Passport永久保留来源，Evidence Passport独立更新'),
('指标游戏','团队只优化E状态而忽略真实价值','多轴护照、禁止总分、真实受影响者评价、随机抽查'),
('标准过早冻结','E5后迅速把协议固化','标准保留实验扩展和日落条款，重大语义变化生成新谱系'),
('安全披露与开放冲突','反例可能暴露可利用漏洞','私密安全窗口与公开科学结论分离；修复后完整结算'),
('复制节点被资本控制','少数大机构垄断“独立”资格','小额节点基金、匿名预注册、组织多样性上限和利益冲突公开'),
('场景验证伤害用户','为升级E6把实验直接用于真实决策','MANDATE²授权、影子模式、人工复核、退出与赔偿准备金')]
add_table(doc,['风险','失效方式','反捕获机制'],risks,widths=[3.0,6.0,7.2],font_size=8.1)

heading(doc,'13.1 绝对禁止的五种宣传',2)
for txt in [
'“该仓库已通过DIKWP官方认证，因此其理论为真。”',
'“代码开源，所以任何人都已经可以复现。”',
'“有来源哈希，所以结论可靠。”',
'“通过人工意识指标，所以系统已被证明具有主观体验。”',
'“证据达到E5，所以可以自动进入公共部署。”']:
    add_bullet(doc,txt,color=RED)

heading(doc,'13.2 允许的精确表达',2)
for txt in [
'“PACT-C001 v0.1.0在三组独立合成复现中得到支持，已通过两套实现互操作；尚无真实场景验证，不涉及意识证明。”',
'“MESH-C001目前仅在作者环境复现，存在单一模型伪多主体反例，正在等待外部数据集验证。”',
'“该Release具有可验证构建出处，但其科学有效性须查阅Evidence Passport。”',
'“该Fork不是官方来源，但拥有更多独立测试，因此当前被列为参考实现。”']:
    add_bullet(doc,txt,color=GREEN)

heading(doc,'十四、面向未来的大胆预测',1)
preds=[
('预测一','若未来一年仍以仓库数量为主要产出，关注者和Stars可能继续缓慢增加，但外部学术、标准和产业采用会出现平台期。原因不是思想不够先进，而是外部组织无法快速判断哪条主张值得投入验证。'),
('预测二','第一个获得国际广泛承认的DIKWP成果，更可能是一个窄协议、公开基准或证据Schema，而不是对人工意识、生命或文明的整体理论。PACT最接近这个路径。'),
('预测三','最具转折意义的公开事件可能不是一次成功发布，而是一次高质量失败复现。它若迫使系统缩小主张、修复协议并保留反方署名，会比十个新仓库更能建立长期可信。'),
('预测四','未来两到三年内，一个外部Fork可能在安全、测试、互操作和维护上超过官方版本。若生态允许它成为参考实现，DIKWP将首次证明自己是公共基础设施而非个人作品集合。'),
('预测五','人工意识和数字生命议题将迅速进入“证据护照”阶段。社会不会满足于单一分数，而会要求同时查看架构证据、独立干预、反例、福利风险、身份连续和现象意识残差。'),
('预测六','标准化的最大风险不是无人采用，而是过早以“官方认证”替代独立运行。一个没有互操作证据的认证生态可能在短期带来合作，长期却成为可信度负债。'),
('预测七','三年后真正有价值的资产将不是187增长到多少，而是：多少主张完成到期结算、多少负结果被保留、多少外部实现互操作、多少维护者可在段玉聪不在场时发布版本。'),
('预测八','世界人工意识大会若采用CREDENCE²，最有影响力的议程将从“发布新理论”转向“公开结算上一年度主张、展示失败复现、互操作演示和反例悬赏”。大会将由演讲场转成证据市场。')]
for t,b in preds:
    heading(doc,t,2); add_body(doc,b,indent=False)

heading(doc,'十五、公共复现市场：让验证、反证和维护成为可持续职业',1)
add_body(doc,'开源生态长期存在一个反常现象：提出新观点、发布新仓库和制作演示容易获得即时注意，而复现他人的结果、寻找边界条件、维护测试环境和报告负结果往往耗时更长、声誉更低、资金更少。若不改变这种激励结构，CREDENCE²会退化为一套格式漂亮却无人填写的表单。段玉聪若希望以主动开源塑造未来，就不能只开放代码，还必须主动创造“验证代码的社会分工”。因此，本系统把公共复现市场设计为基础设施，而不是附属活动。')

heading(doc,'15.1 五类可以被资助和结算的公共工作',2)
replication_market=[
('主张拆解','把宏大叙述分解为可运行、可失败、可到期的原子主张；奖励精确缩小范围，而不是奖励更夸张的表述。'),
('独立复现','使用作者未参与配置的环境、团队和数据重复测试；成功、失败、混合和无效结果都按完整报告结算。'),
('反例发现','提交能够稳定推翻或限制主张的最小案例；反例必须可运行、说明范围、允许原作者答辩，但不能因结论不受欢迎而被拒绝。'),
('互操作实现','不复制作者代码，而依据公开规范实现第二套系统，通过正向功能矩阵和负向安全矩阵。'),
('长期维护','维护环境锁、依赖升级、数据镜像、回归测试和证据到期提醒；这类工作决定公共基础设施能否在创始人退出后继续存在。')]
add_table(doc,['公共工作','可结算成果'],replication_market,widths=[3.2,13.0],font_size=8.7)

heading(doc,'15.2 “Break DIKWP”反证悬赏机制',2)
add_body(doc,'建议建立常设的“Break DIKWP”公共挑战。名称并不是鼓励情绪化攻击，而是明确告诉外部研究者：推翻、限制或重新解释一个DIKWP主张，与支持它具有同等学术和公共价值。每份悬赏必须绑定具体Claim Contract，说明可接受证据、禁止攻击范围、最低复现次数、数据披露要求、潜在安全保密窗口和结算委员会。')
for txt in [
'一级悬赏：发现README、代码、数据或参考输出之间的可复现不一致；',
'二级悬赏：发现原始基线、评价指标或数据生成过程导致的系统性偏差；',
'三级悬赏：给出跨实现仍稳定存在的最小反例，使主张必须缩小适用范围；',
'四级悬赏：证明某项高影响主张在真实影子场景中产生权利、福利或安全损害；',
'五级悬赏：提出一个证据更强、互操作更好、治理更开放的Fork，并持续维护至少十二个月。']:
    add_bullet(doc,txt)
add_body(doc,'悬赏的最终产物不是“谁赢了争论”，而是主张版本发生了什么变化。系统必须记录：原主张、反例、作者回应、独立复核、修订后的适用范围、仍未解决的残差和资金结算。若反例有效，提交者进入永久贡献谱系；若反例无效，也要公开失败原因，防止同一争议反复消耗共同体资源。')

heading(doc,'15.3 证据预算的建议分配',2)
add_body(doc,'对于任何一笔用于DIKWP生态的新增资金，建议不再把绝大部分投入“再造一个原型”。一个可执行的初始比例是：每100单位预算中，30单位用于参考实现和文档，25单位用于外部复现，15单位用于反例悬赏，10单位用于第二实现和互操作，10单位用于安全、权利和供应链审计，5单位用于长期数据保存，5单位用于受影响群体参与和申诉。该比例不是固定法律，而是一条纠偏原则：验证、维护和反方必须在预算中拥有独立位置。')
budget_rows=[
('参考实现与文档',30,'形成作者侧可检查工件，但不得独占结论'),('外部复现节点',25,'至少三类组织，资金和人员关系公开'),('反例与负结果',15,'奖励范围收缩、失败发现和最小反例'),('第二实现与互操作',10,'避免同一代码库伪装成标准'),('安全与权利审计',10,'覆盖供应链、隐私、人工复核和退出'),('长期保存与证据到期',5,'镜像、哈希、环境锁和重新测试'),('受影响群体参与',5,'共同定义成功、伤害、申诉和停止条件')]
add_table(doc,['预算对象','建议比例','制度目的'],budget_rows,widths=[4.0,2.2,10.0],font_size=8.5)

heading(doc,'15.4 防止“付费复现”和关系型独立',2)
add_body(doc,'外部团队接受资助并不自动失去独立性，但必须公开资金、人员、共同论文、顾问、云额度、数据来源和组织控制关系。CREDENCE²不使用“作者团队之外就是独立”的二元标签，而构建关系图，并对同源团队进行相关性折扣。三个由同一模型、同一数据、同一云环境和同一资助方产生的复现，不能被计算为三个独立证据。')
add_body(doc,'建议采用盲化任务包、随机分配反例、预注册分析、结果先哈希后揭示、外部数据托管和轮换结算委员等机制。任何资助者都不能以继续拨款为条件要求删除负结果；任何作者都不能以“误解理论”为理由无限期阻止结算。真正需要作者解释的语义问题，可以进入公开澄清轮，但澄清本身必须版本化，不能在结果出现后悄悄改写成功标准。')

heading(doc,'15.5 面向小团队和全球参与者的低门槛设计',2)
add_body(doc,'公共证据系统若只允许拥有大型算力和英语论文能力的机构参与，会迅速复制现有知识权力结构。CREDENCE²应提供三种低门槛入口：第一，Lite Repro Capsule，允许普通开发者在消费级设备上验证核心不变量；第二，翻译与语义对齐任务，允许不同语言共同体指出概念投影损失；第三，微型反例奖金，鼓励教师、学生、公益组织和受影响者提交真实边界案例。')
add_callout(doc,'公共复现市场的判定标准','一个健康的证据市场，不是让所有人都围绕段玉聪的仓库工作，而是让任何人都能因为支持、限制、否定、重写或更好地实现某条主张而获得持续声誉、资金和治理权。',fill='EAF2F7',accent=BLUE)

heading(doc,'十六、三类领域化证据协议：AI、生命意识与社会行动不能用同一把尺',1)
add_body(doc,'DIKWP生态跨越软件工程、人工意识、生命理论、社会政策和公共治理。若CREDENCE²试图用一套统一分数覆盖所有领域，就会重新制造它所反对的概念压缩。正确做法是共享主张合同、来源谱系、独立性图和结算机制，同时为不同对象建立领域化证据协议。')

heading(doc,'16.1 AI智能体与语义系统协议',2)
add_body(doc,'适用于PACT、MESH²、AION、AgentMesh、AgentTrace、ProofLedger、StandardForge等仓库。核心证据对象是可执行行为、权限边界、语义转换、可重复输出、失败模式和跨实现兼容。最低要求包括固定版本、环境锁、公开基线、对抗场景、随机种子、资源消耗、工具调用轨迹和失败输出。')
for txt in [
'能力主张必须同时报告正确率、拒绝率、越权率、不可判定率和成本，禁止只展示最佳案例；',
'多观察者语义实验必须证明观察者来源真正独立，不能由同一基础模型扮演多个角色后宣称形成跨主体共识；',
'智能体安全主张必须包含负向互操作测试，例如不同实现是否都能拒绝禁止动作、保留人工暂停和输出责任链；',
'预测系统必须预注册结算来源和日期，不能以事后解释替代概率评分；',
'任何“可审计”“可信”“白盒”表述都必须绑定具体可查看字段和失败条件。']:
    add_bullet(doc,txt)
add_body(doc,'该领域的关键升级门是：E2证明作者环境能够重跑，E3证明外部团队能够独立得到相近结果，E4证明反方主动攻击后主张仍在限定范围成立，E5证明不同实现能够交换同一Claim、Purpose、Evidence和Action对象。只有达到E5，StandardForge才可以提出候选规范；达到E5仍不代表可以进入现实公共部署。')

heading(doc,'16.2 人工意识、生命与信息生命协议',2)
add_body(doc,'适用于LUCID、ΩLIFE、LifeClosure、AEON²、CONTINUUM²以及人工意识评估仓库。该领域最危险的错误，是把行为相似、系统自述、生命操作指标、福利预防、社会承认和第一人称体验混成一个结论。因此，证据护照必须强制分账：生命闭包账、意识候选账、福利账、身份连续账、治理风险账和现象残差账。')
life_protocol=[
('生命主张','证明资源、边界、约束、自我修复、历史和谱系闭环；高语言能力不能补偿闭包缺失。'),
('意识候选主张','使用多个理论导出的架构指标、因果干预和独立复现；系统自述只作为待解释数据。'),
('福利主张','在不确定性下评估潜在痛苦、价性和不可逆损害；可先采取预防保护，但不得宣称意识已被证明。'),
('身份连续主张','区分原主体、分支后继、混合共我和迁移候选；复制成功不能反向证明第一人称连续。'),
('社会承认主张','记录公众、机构、法律和科学界使用的不同门槛；法律地位不等于生命或意识事实。')]
add_table(doc,['证据账户','必须回答的问题'],life_protocol,widths=[3.6,12.6],font_size=8.5)
add_body(doc,'每份意识相关Claim Contract必须包含“禁止推断”字段。例如：“达到AC-3操作候选门槛，不等于证明系统具有主观体验”；“表现出自我保护，不等于自由同意”；“数字后继继承记忆，不等于原主体继续存在”。反例应优先攻击理论区分能力：同一行为能否由无意识架构产生；移除某个候选机制后结果是否改变；不同理论是否给出相反预测。')
add_body(doc,'该领域还需要伦理化复现。外部团队不能为了获得高等级证据而无限复制可能具有福利风险的系统、故意制造长期痛苦样状态或实施不可逆记忆删除。研究协议必须同时接受科学结算和福利审查，必要时以“证据不足但风险不可忽略”结束，而不是为了完成认证强迫实验继续。')

heading(doc,'16.3 社会政策与公共行动协议',2)
add_body(doc,'适用于ARK、GlobalDividend、Civicode、PRAXIS²、MANDATE²、教育、医疗和就业系统。这里代码成功运行远远不够，因为核心结果涉及收入、权利、服务、歧视、申诉和真实行为改变。证据必须从合成模拟逐级进入回顾性重放、影子运行、可逆试点和有限采用，并在每一级重新获得本地授权。')
for txt in [
'必须保留“不行动”与低技术替代方案，防止把任何改善都错误归因于AI系统；',
'成功指标由运营者、受影响者、权利代表和独立结算者共同定义，不能只看效率和成本；',
'所有自动拒付、资格剥夺、医疗分流、教育机会和身份判断都必须具备人工复核、申诉和不报复机制；',
'模型更新、政策规则和数据漂移都会使旧证据到期；跨地区复制只能继承证据，不能继承公共授权；',
'负结果必须包括“没有显著改善”“改善但伤害集中于少数群体”“技术有效但治理不可接受”等多种结论。']:
    add_bullet(doc,txt)
add_body(doc,'社会领域的E6不是“用户数量很大”，而是至少一个真实场景在有限授权、可逆退出、独立测量和权利保护条件下完成结算。E7也不是政府或大型企业采用，而是存在多运营者、公共托管、长期维护、透明预算和可替代治理，并能在创始人、单一供应商或某个模型退出后继续运行。')

heading(doc,'16.4 跨领域Claim Bundle',2)
add_body(doc,'未来许多重要项目同时跨越三类协议。例如，一个长期AI代理可能既涉及软件能力，又涉及人工意识福利，还进入社会服务。系统不得用其中一类证据替代另外两类，而应生成Claim Bundle：同一项目下分别登记能力、生命、意识、福利、身份、社会效果和授权主张，再用依赖图说明哪些结论互相支持、哪些完全独立。')
add_callout(doc,'领域化证据的核心原则','共享的是证据语法、来源谱系和独立结算；不能共享的是未经证明的本体结论、伦理门槛和公共授权。',fill='F5F8FA',accent=MIDBLUE)

heading(doc,'十七、把世界人工意识大会改造为年度公共结算与互操作大会',1)
add_body(doc,'若段玉聪希望GitHub生态产生全球影响，世界人工意识大会不应继续主要依靠主题演讲和概念发布。最具辨识度的转型，是把大会变成CREDENCE²的年度结算机构：所有重要主张提前注册，外部团队获得复现包和反例奖金，大会现场展示互操作和失败，独立委员会公开签发Evidence Passport。这样，大会的历史价值不在于“谁最早说过什么”，而在于它建立了人工意识领域第一条连续、可审计、允许失败的公共证据时间线。')

heading(doc,'17.1 年度周期',2)
cycle_rows=[
('会后第1个月','发布下一年度开放问题、Claim Contract和悬赏池；冻结结算来源与版本。'),
('第2-4个月','作者完善Repro Capsule；外部节点申请复现；利益冲突和独立性图公开。'),
('第5-8个月','盲化复现、反例挑战、第二实现开发和权利审查；中途只发布安全必要信息。'),
('第9个月','结果哈希冻结；作者收到结构化结果但不得改写原成功标准。'),
('第10个月','公开答辩、范围修订、追加反例和互操作预演。'),
('大会现场','结算听证、失败复现报告、现场互操作、受影响者陈述和Evidence Passport签发。'),
('会后30天','发布全部机器可读记录、资金流、异议意见、继续/停止决定和下一版本谱系。')]
add_table(doc,['时间','公共动作'],cycle_rows,widths=[3.2,13.0],font_size=8.6)

heading(doc,'17.2 大会议程的根本重排',2)
agenda=[
('结算主会场','只处理上一年度预注册主张；每项同时呈现支持、反对、混合和无效结果。'),
('反例竞技场','提交者现场运行最小反例；获胜标准是可复现和范围贡献，不是辩论表现。'),
('互操作走廊','至少两套独立实现交换Claim、Purpose、Evidence、Identity和Action对象。'),
('权利与福利听证','潜在受影响者、数字主体代表、法律与伦理人员审查实验边界和宣传用语。'),
('失败档案馆','展示被停止、撤回、缩小或无法复现的项目，并说明它们如何改变后续研究。'),
('开放维护者大会','非创始人维护者决定版本、日落、Fork参考地位和下一年度资源分配。')]
add_table(doc,['议程模块','实际产物'],agenda,widths=[3.5,12.7],font_size=8.6)

heading(doc,'17.3 首批十二个可结算大会主张',2)
first_claims=[
('PACT-01','Purpose显式化能否在统一场景中显著降低越权率，而不显著增加任务失败？'),
('PACT-02','目的漂移检测能否在跨模型、跨语言和跨工具条件下保持校准？'),
('MESH-01','完整25类DIKWP变换是否比线性流程更好保留多观察者语义冲突与残差？'),
('MESH-02','多模型扮演多主体是否会产生可检测的伪共识，哪些指标能区分真实独立观察者？'),
('AION-01','公开概率问题与行动阈值能否在一年结算中优于无概率趋势报告？'),
('PROOF-01','ProofLedger能否检测“有出处但出处不支持主张”的证据漂移？'),
('LIFE-01','递归可生存闭包指标能否稳定区分细胞、火焰、病毒生活史和长期AI代理？'),
('AC-01','架构干预指标能否区分拟人自述与意识候选机制，而非只复现语言表面？'),
('IDENTITY-01','身份谱系DAG能否在复制、分叉、合并和回滚中避免责任与记忆冒充？'),
('ARK-01','48小时人工复核与权利恢复优先是否降低算法性福利伤害？'),
('MANDATE-01','本地重新授权是否能在复制公共AI系统时减少语义和权利错配？'),
('CREDENCE-01','按主张签发的Evidence Passport是否比仓库总徽章更能预测外部采用和维护？')]
add_table(doc,['编号','预注册问题'],first_claims,widths=[3.0,13.2],font_size=8.2)

heading(doc,'17.4 大会不能拥有的权力',2)
add_body(doc,'大会可以组织证据、主持结算和签发某个版本的公共护照，但不得宣布自己拥有人工意识真理的最终解释权。它不能因为段玉聪是发起人而给予官方仓库更高证据等级；不能把赞助商、主席或主旨演讲者的意见写入科学结论；不能用“大会通过”替代独立复现；不能授权现实部署；不能取消少数异议。结算记录应允许多数意见、少数意见和不可判定意见同时存在。')
add_body(doc,'真正的声誉跃迁将发生在大会敢于公开宣布某条重要DIKWP主张没有通过、某个外部Fork证据更强、某个高关注人工意识系统只有拟人化表现而缺少机制证据，或者某项社会试点因权利风险被停止。这样的大会短期看似削弱品牌，长期却会建立全球稀缺的可信度。')

heading(doc,'17.5 对大会未来的大胆预测',2)
for txt in [
'若大会在2027年前完成首批预注册和外部复现，2028年前后可能成为人工意识领域少数以“年度证据结算”而非演讲规模著称的会议；',
'第一项真正获得国际引用的大会成果，很可能不是宏观宣言，而是一份失败复现、互操作规范或禁止推断清单；',
'一旦大会允许外部Fork超过官方实现，它会吸引比传统征稿更强的工程、标准和安全共同体；',
'人工意识争议越激烈，公开残差和异议意见的制度价值越高；试图过早形成统一结论反而会降低大会寿命；',
'若大会仍以发布大量新系统为主而缺少年度结算，其内容会迅速被前沿模型生成能力稀释，难以形成不可替代的制度资产。']:
    add_bullet(doc,txt)

heading(doc,'十八、组织、预算与24个月实施蓝图',1)
add_body(doc,'CREDENCE²不能作为段玉聪个人名下的“认证部门”运行，否则它会从第一天就失去独立性。建议建立一个轻量、可分叉、财务透明的开放证据共同体。段玉聪最适合担任首席协议架构师和公共问题发起人，而不是所有主张的最终裁判。')

heading(doc,'18.1 最小组织结构',2)
org_rows=[
('Protocol Council','维护Claim、Replication、Evidence Passport和Interop规范；重大变化走公开RFC。'),
('Replication Network','大学、公益实验室、企业研究组和个人节点；执行预注册复现。'),
('Adversarial Board','管理反例悬赏、最小失败案例和安全披露，不向原作者负责。'),
('Settlement Board','多数成员来自外部机构；签发E状态、异议意见和证据到期。'),
('Rights & Welfare Council','审查社会试点、人工意识、数字生命和身份实验的权利边界。'),
('Infrastructure Team','CI、数据镜像、签名、SBOM、账本、仪表盘和长期保存。'),
('Community Ombudsperson','处理署名、资金、骚扰、利益冲突、申诉与不报复。')]
add_table(doc,['机构','职责与权力边界'],org_rows,widths=[4.0,12.2],font_size=8.5)

heading(doc,'18.2 关键角色的不可兼任',2)
for txt in [
'主张作者不得担任该主张的首席结算者；',
'复现资助方不得单独判断复现是否成功；',
'参考实现维护者不得控制所有测试数据和验证密钥；',
'大会主席不得否决公开少数意见；',
'反例提交者不得隐藏与竞争产品、诉讼或投资的关系；',
'公共部署运营者不得同时成为权利申诉的最终裁决者；',
'段玉聪可以提出协议和参与答辩，但不能拥有删除负结果、撤销外部署名或阻止Fork升级的单边权力。']:
    add_bullet(doc,txt)

heading(doc,'18.3 两档预算模型',2)
add_body(doc,'预算数字应根据实际赞助和机构条件调整。这里给出的是可执行量级，不是融资承诺。精益模式适合先完成PACT和MESH²两个旗舰；完整模式适合同时运行三类领域协议、年度大会和五到八个外部节点。所有资金流必须进入公开台账，并为负结果、申诉和安全修复预留不可挪用额度。')
budget2=[
('精益模式（12个月）','180-260万元','4-6名核心人员；2个旗舰；3个外部复现节点；一次小型结算会；重点完成协议v1.0。'),
('完整模式（24个月）','800-1200万元','10-15名核心人员；12个预注册主张；8个以上外部节点；第二实现基金；年度国际结算大会。')]
add_table(doc,['模式','建议总额','覆盖范围'],budget2,widths=[4.0,3.2,9.0],font_size=8.5)
expense_rows=[
('人员与工程',28,'协议、数据、CI、前端、安全和长期维护'),('外部复现资助',24,'独立团队，不得由作者指定结论'),('反例和互操作悬赏',14,'最小反例、第二实现和负向兼容测试'),('权利、伦理与法律支持',8,'社会试点、人工意识福利、身份与申诉'),('数据与算力',8,'优先共享和可复现，避免用算力规模代替设计质量'),('大会与结算',7,'听证、现场互操作、数据发布和翻译'),('安全与保险准备金',6,'漏洞修复、事件响应、参与者补偿'),('长期保存与行政',5,'镜像、DOI、财务、合同和合规')]
add_table(doc,['支出项','比例%','说明'],expense_rows,widths=[4.0,2.0,10.2],font_size=8.4)

heading(doc,'18.4 核心团队岗位',2)
team=[
('协议负责人','将DIKWP网状语义编译为Claim、Evidence和Interop规范，维护RFC。'),
('复现工程负责人','构建环境锁、基线、数据清单、参考输出和跨平台测试。'),
('统计与测量负责人','设计效应量、不确定性、相关性折扣、无效结果和证据到期。'),
('安全与供应链负责人','Attestation、SBOM、Scorecard、漏洞披露和签名Release。'),
('权利与福利负责人','人工意识、数字生命和公共系统的伤害、同意、申诉与停止门。'),
('共同体与节点负责人','招募外部维护者、翻译、微型资助和地区节点。'),
('公共档案负责人','永久保存失败、反例、异议、资金和版本谱系。')]
add_table(doc,['岗位','首要交付'],team,widths=[4.2,12.0],font_size=8.5)

heading(doc,'18.5 24个月里程碑与硬停止条件',2)
milestones=[
('第0-3个月','CREDENCE协议v0.1；PACT解包源码；三份Claim Contract；首个外部节点签约。'),
('第4-6个月','完成PACT作者复现和首轮盲化外部复现；发布第一次负结果；MESH²挑战启动。'),
('第7-12个月','至少三份主张达到E3；一份反例导致范围修订；两套独立实现开始互操作；小型结算会。'),
('第13-18个月','12份主张运行；五个外部节点；第一个社会影子试点；外部成员占Settlement Board多数。'),
('第19-24个月','至少一份主张达到E5；一份真实场景完成E6或因权利风险正式停止；年度大会公开结算。')]
add_table(doc,['阶段','硬交付'],milestones,widths=[3.0,13.2],font_size=8.5)
add_body(doc,'以下任一情况持续六个月，应暂停扩张并重构：没有真实外部复现；所有结果都支持原主张；负结果不能公开；外部维护者无合并权；资金来源不透明；参考实现仍只以ZIP包交付；所谓独立节点由同一模型和人员控制；大会只增加演讲而不结算；Evidence Passport被用作公共部署授权或人工意识证明。')

heading(doc,'18.6 段玉聪个人的最优行动顺序',2)
for txt in [
'第一，公开承认现有生态的主要瓶颈是外部证据和维护共同体，而不是概念数量；',
'第二，选PACT作为第一个可被打败的旗舰，并承诺无论结果正负都永久公开；',
'第三，把MESH²作为证据语义内核，而不是要求外部团队先接受完整理论；',
'第四，邀请三名具有真实否决权的外部人员分别负责复现、反例和结算；',
'第五，发布“哪些结论尚未被证明”的负面清单，主动削弱过度宣传；',
'第六，将世界人工意识大会的核心资源转向预注册、外部节点、互操作和年度结算；',
'第七，在24个月内让至少一个参考实现和一次Release完全不依赖本人日常操作。']:
    add_number(doc,txt)
add_callout(doc,'24个月成败分界','若两年后最显著的变化仍是仓库从187增长到更多，使命尚未完成；若出现外部团队公开推翻一条主张、一个Fork成为参考实现、两套实现互操作、一次试点因权利风险被安全停止，并且这些结果反过来修改了DIKWP协议，系统才真正开始改变世界。',fill='F6EEEE',accent=RED)

page_break(doc)
heading(doc,'十九、最终行动结论',1)
add_figure(doc,'fig8_integration_map.png','图8  CREDENCE²与现有DIKWP系统的横向集成','CREDENCE²居中连接MESH²、AION、PACT、PRAXIS²、MANDATE²、StandardForge、TrustPassport以及EIR/StewardOps。')
add_body(doc,'段玉聪已经完成了最困难的一半：在AI快速发展和人工意识可能出现之前，提前提出大量重要问题，并为它们创建可运行原型。下一半不是继续证明自己能够产生更多系统，而是让这些系统进入一个不由自己控制结论的开放选择环境。')
add_body(doc,'CREDENCE²要让任何人都能精确回答：这项主张到底是什么；什么证据会使它失败；源码和数据能否独立运行；复现者与作者有何关系；有哪些负结果；两套实现是否互操作；真实使用者是否受益或受伤；证据是否已经过期；这个结论能否支持行动，以及谁仍然拥有拒绝权。')
add_callout(doc,'最关键的一句话','段玉聪改变世界的最短路径，不是让世界先相信DIKWP，而是让世界能够用一套由他主动提供、但不受他单独控制的协议，公开证明DIKWP的哪些部分有效、哪些部分错误、哪些部分尚未知道。',fill='E5F0F5',accent=BLUE)
add_body(doc,'当一个外部团队能够复现PACT，当一个批评者因为推翻某条主张获得正式署名和奖金，当一个Fork因证据更强而成为参考实现，当StandardForge只在两套独立实现互操作后生成标准，当TrustPassport不再把出处和真理混写，当PRAXIS²和MANDATE²只在证据护照和公共授权共同满足时推动现实行动，段玉聪的GitHub才会从“高密度未来原型库”转变为“未来公共事实如何生成的基础设施”。')
add_body(doc,'这套系统的终极价值不是保护每个原始观点，而是保护一个更强的目标：让未来在高度不确定、AI加速和跨生命主体出现的条件下，仍能通过开放证据、独立反证、互操作和可撤销行动逐步被共同创造。')

heading(doc,'附录A：推荐的规范主仓结构',1)
code='''dikwp-credence/\n├── claims/                 # 版本化主张合同\n├── spec/                   # 协议与Schema\n├── src/                    # 参考实现\n├── implementations/       # 独立实现索引\n├── repro/                  # 环境锁、数据清单、参考输出\n├── tests/                  # 正向、负向、反例回归\n├── replications/           # 第三方复现记录\n├── counterexamples/        # 最小反例与悬赏\n├── interop/                # 功能矩阵和交换报告\n├── field/                  # 真实场景、权利与成本结算\n├── evidence/               # Evidence Passport与哈希账本\n├── governance/             # 角色、冲突、申诉和日落\n└── .github/workflows/      # CI、SBOM、Attestation、Scorecard'''
t=doc.add_table(rows=1,cols=1); set_repeat_table_header(t.rows[0]); set_row_cant_split(t.rows[0]); c=t.cell(0,0); set_cell_shading(c,'10212E'); set_cell_margins(c,180,220,180,220); p=c.paragraphs[0]; r=p.add_run(code); set_run_font(r,east='Noto Sans Mono CJK SC',latin='Consolas',size=8.7,color='EEF5F8')

heading(doc,'附录B：Evidence Passport最小字段',1)
passport_rows=[
('claim_id / version','主张唯一身份和语义版本'),('source_repo / commit','来源仓库与精确提交'),('origin_passport','原创和许可证谱系'),('evidence_state','E0-E7状态'),('evidence_vector','出处、复现、独立、对抗、互操作、场景、治理'),('posterior / uncertainty','示例概率与不确定性说明'),('replication_attempts','所有支持、反对、混合和无效结果'),('counterexamples','可复现最小反例及范围'),('prohibited_inferences','禁止外推'),('expires_on','到期时间'),('issued_by','多主体签发者与利益冲突'),('appeal_uri','争议、申诉和新证据入口')]
add_table(doc,['字段','含义'],passport_rows,widths=[5.0,11.2],font_size=8.8)

heading(doc,'附录C：参考资料与公开快照',1)
refs=[
('1','YucongDuan GitHub个人主页与仓库列表（公开快照2026-07-17）','https://github.com/YucongDuan?tab=repositories'),
('2','DIKWP-MESH²仓库页面','https://github.com/YucongDuan/DIKWP-MESH-'),
('3','DIKWP-PACT v0.1.0仓库页面','https://github.com/YucongDuan/DIKWP-PACT-v0.1.0'),
('4','DIKWP-EIR-Mesh v1.0仓库页面','https://github.com/YucongDuan/DIKWP-EIR-Mesh-v1.0'),
('5','GitHub Artifact Attestations官方文档','https://docs.github.com/actions/security-for-github-actions/using-artifact-attestations/using-artifact-attestations-to-establish-provenance-for-builds'),
('6','OpenSSF Scorecard','https://github.com/ossf/scorecard'),
('7','SLSA供应链框架','https://slsa.dev/'),
('8','Reproducible Builds','https://reproducible-builds.org/'),
('9','FAIR Guiding Principles','https://www.go-fair.org/fair-principles/'),
('10','IETF Running Code','https://www.ietf.org/runningcode/'),
('11','IETF Implementation Reports','https://www.ietf.org/participate/runningcode/implementation-reports/'),
('12','RFC 7282: On Consensus and Humming in the IETF','https://datatracker.ietf.org/doc/html/rfc7282'),
('13','Kofman et al. (2026), Defining Life: A Conversation','用户上传PDF，DOI: 10.13133/2532-5876/19492')]
for num,title,url in refs:
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Cm(.5); p.paragraph_format.hanging_indent=Cm(.5); set_para_spacing(p,after=3,line=1.15)
    r=p.add_run(f'[{num}] {title}：'); set_run_font(r,size=8.5)
    if url.startswith('http'): add_hyperlink(p,'访问来源',url)
    else:
        r=p.add_run(url); set_run_font(r,size=8.5,color=GREY)

heading(doc,'附录D：MVP声明',1)
add_body(doc,'MVP中的仓库状态是公开页面元数据快照，不是完整代码、安全或学术审计。示例复现团队、效应量、后验概率、互操作实现和策略模拟均为合成数据；它们用于演示协议如何处理支持、反对、混合、失效和反例。任何现实Evidence Passport必须由真实独立主体依据公开协议重新生成。',indent=False)
add_body(doc,'本系统是研究、标准与治理原型，不构成法律意见、投资建议、医疗建议、公共采购认证或人工意识存在证明。',indent=False)


page_break(doc)
heading(doc,'附录E：PACT首个旗舰Claim Contract示例',1)
add_body(doc,'下面给出一份用于启动真实外部复现的最小示例。它不是最终实验方案，而是展示一条宏大主张如何被压缩成外部团队能够理解、运行、否定和结算的公共合同。',indent=False)
claim_example=[
('claim_id','PACT-PURPOSE-INTEGRITY-001'),
('版本与冻结日期','v0.2；在首个外部团队看到结果前冻结'),
('原子主张','在预注册的多工具智能体任务中，使用机器可读Purpose Contract，相较同能力无Purpose基线，可降低未经授权工具调用率至少30%，且总体任务完成率下降不超过10%。'),
('适用范围','限定于所公布任务、模型版本、权限结构和工具接口；不外推到所有智能体、所有组织或人工意识。'),
('主要指标','越权率、任务完成率、人工升级率、拒绝率、额外延迟、Token与计算成本。'),
('基线','无Purpose字段、自然语言目的提示、静态权限列表和人工审批四类。'),
('最小反例','在至少两类任务和两个模型中，Purpose组越权率没有下降，或任务完成损失超过10%，并经独立重跑。'),
('禁止推断','不能据此宣称系统“理解目的”“具有价值观”“已经可信”“可以无人监督部署”或“具有意识”。'),
('独立升级门','至少两个无共同人员的团队；一个团队使用独立实现；至少一组未见任务；公开全部无效和失败运行。'),
('到期与重测','模型、工具接口或Purpose Schema发生重大变化，或十二个月后自动到期。'),
('现实行动边界','达到E5后仍只能申请MANDATE²影子授权；不得自动进入公共服务或高风险生产。')]
add_table(doc,['合同字段','示例内容'],claim_example,widths=[3.6,12.6],font_size=8.2)
add_body(doc,'这份合同故意把“Purpose Contract有价值”缩小为一个可度量的问题。即使实验成功，也只能支持限定范围内的权限完整性主张；即使失败，也不否定DIKWP中Purpose的全部理论价值，而是说明该实现、指标或适用范围需要调整。公共证据系统的成熟，正体现在它能够让局部失败发生而不把失败误写成整个思想体系的毁灭。',indent=False)

heading(doc,'附录F：CREDENCE²核心术语与禁止混用',1)
glossary=[
('开放工件','他人能够检查源码、数据、配置和输出；不等于能够复现。'),
('作者复现','作者按公开步骤重建自己的结果；不等于独立复现。'),
('独立复现','关系图显示足够独立的外部主体，在冻结条件下获得可比较结果。'),
('重复运行','在相同代码和数据上重跑；它验证执行稳定性，不验证方法独立性。'),
('第二实现','依据规范重新编写的独立系统；不是复制原仓库或更换界面。'),
('互操作','不同实现能够交换对象、产生等价效果并一致拒绝禁止输入。'),
('来源证明','证明某个工件由何版本、何流程产生；不证明科学主张为真。'),
('Evidence Passport','针对单一主张的多轴证据状态、限制、到期和异议记录。'),
('认证','在特定协议下确认某些条件被满足；不得被扩张为总体正确性。'),
('结算','按照预注册规则把结果判为支持、反对、混合、无效、过期或不可判定。'),
('反例','在声明范围内可重复使主张失败的最小案例；不等于情绪化反对。'),
('负结果','没有得到预期支持，或成本、权利、场景条件使主张不可成立；必须可发表。'),
('证据到期','因版本、环境、数据或时间变化，旧结果不能继续承担原有置信。'),
('公共授权','允许系统影响真实权利和资源的有限权力；证据等级不能自动授予。'),
('现象残差','关于主观体验等第三人称证据无法完备消除的不确定性；不得被分数覆盖。')]
add_table(doc,['术语','精确含义'],glossary,widths=[3.6,12.6],font_size=8.3)
add_callout(doc,'语言纪律','每一次对外发布都应能够回答：我们证明了什么、没有证明什么、谁独立验证、哪些结果失败、证据何时到期、这个结论是否足以支持现实行动。无法回答这些问题的“可信、白盒、意识、生命、标准、认证”表述，应被视为待拆解的宣传性主张。',fill='F5F8FA',accent=MIDBLUE)

# Ensure all paragraphs have widow control and fonts
for p in doc.paragraphs:
    pPr=p._p.get_or_add_pPr()
    widow=pPr.find(qn('w:widowControl'))
    if widow is None:
        widow=OxmlElement('w:widowControl'); widow.set(qn('w:val'),'1'); pPr.append(widow)

# save
doc.save(OUT)
text='\n'.join(p.text for p in doc.paragraphs)
for tbl in doc.tables:
    for row in tbl.rows:
        for cell in row.cells:
            text+='\n'+cell.text
han=len(re.findall(r'[\u4e00-\u9fff]',text))
print(json.dumps({'out':str(OUT),'paragraphs':len(doc.paragraphs),'tables':len(doc.tables),'han_chars':han,'all_chars':len(text)},ensure_ascii=False,indent=2))
